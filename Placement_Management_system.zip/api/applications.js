import supabase from './db-client.js';

const VALID = ['applied', 'shortlisted', 'selected', 'rejected', 'withdrawn'];

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { student_id, job_id, status, search, page = '1', limit = '50', id } = req.query;
      const { data: jobs } = await supabase.from('jobs').select('*');
      const { data: students } = await supabase.from('students').select('*');
      const { data: companies } = await supabase.from('companies').select('*');
      const jmap = {}; (jobs || []).forEach(j => { jmap[j.id] = j; });
      const smap = {}; (students || []).forEach(s => { smap[s.id] = s; });
      const cmap = {}; (companies || []).forEach(c => { cmap[c.id] = c; });
      const enrich = (a) => {
        const job = jmap[a.job_id];
        return { ...a, job: job || null, student: smap[a.student_id] || null, company: job ? (cmap[job.company_id] || null) : null };
      };
      if (id) {
        const { data, error } = await supabase.from('applications').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(enrich(data));
      }
      let q = supabase.from('applications').select('*', { count: 'exact' }).order('id', { ascending: false });
      if (student_id) q = q.eq('student_id', student_id);
      if (job_id) q = q.eq('job_id', job_id);
      if (status) q = q.eq('status', status);
      const pg = Math.max(1, parseInt(page));
      const lim = Math.min(200, Math.max(1, parseInt(limit)));
      if (search) {
        const { data, error } = await q;
        if (error) throw error;
        const s = String(search).toLowerCase();
        let enriched = (data || []).map(enrich);
        enriched = enriched.filter(a => (a.student?.name || '').toLowerCase().includes(s) || (a.job?.title || '').toLowerCase().includes(s) || (a.company?.name || '').toLowerCase().includes(s) || (a.student?.student_id || '').toLowerCase().includes(s));
        const total = enriched.length;
        return res.status(200).json({ data: enriched.slice((pg - 1) * lim, pg * lim), total, page: pg, limit: lim });
      }
      q = q.range((pg - 1) * lim, pg * lim - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      return res.status(200).json({ data: (data || []).map(enrich), total: count || 0, page: pg, limit: lim });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.job_id) return res.status(400).json({ error: 'job_id is required' });
      if (!b.student_id) return res.status(400).json({ error: 'student_id is required' });
      const { data: job } = await supabase.from('jobs').select('*').eq('id', b.job_id).single();
      if (!job) return res.status(404).json({ error: 'Job not found' });
      if (job.status !== 'open') return res.status(400).json({ error: 'This job is no longer accepting applications' });
      const { data: stu } = await supabase.from('students').select('*').eq('id', b.student_id).single();
      if (!stu) return res.status(404).json({ error: 'Student not found' });
      if (job.min_cgpa && stu.cgpa !== null && Number(stu.cgpa) < Number(job.min_cgpa)) return res.status(400).json({ error: 'Minimum CGPA ' + job.min_cgpa + ' required for this job' });
      if (job.department && job.department !== 'All') {
        const allowed = String(job.department).split(',').map(x => x.trim());
        if (!allowed.includes(stu.department)) return res.status(400).json({ error: 'Only ' + job.department + ' students are eligible' });
      }
      const { data: dup } = await supabase.from('applications').select('id').eq('job_id', b.job_id).eq('student_id', b.student_id).limit(1);
      if (dup && dup.length) return res.status(409).json({ error: 'You have already applied for this job' });
      const { data, error } = await supabase.from('applications').insert({ job_id: b.job_id, student_id: b.student_id, status: 'applied', cover_note: b.cover_note || null }).select().single();
      if (error) throw error;
      if (stu.user_id) {
        await supabase.from('notifications').insert({ user_id: stu.user_id, title: 'Application submitted', message: 'Your application for ' + job.title + ' has been submitted successfully.', type: 'success' });
      }
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      if (b.status && !VALID.includes(b.status)) return res.status(400).json({ error: 'Invalid status' });
      const patch = { updated_at: new Date().toISOString() };
      if (b.status) patch.status = b.status;
      if (b.cover_note !== undefined) patch.cover_note = b.cover_note;
      const { data, error } = await supabase.from('applications').update(patch).eq('id', b.id).select().single();
      if (error) throw error;
      const { data: stu } = await supabase.from('students').select('user_id').eq('id', data.student_id).single();
      const { data: job } = await supabase.from('jobs').select('title').eq('id', data.job_id).single();
      if (stu?.user_id && b.status) {
        const jt = job?.title || 'a job';
        const msgs = {
          shortlisted: 'Great news! You have been shortlisted for ' + jt + '.',
          selected: 'Congratulations! You have been SELECTED for ' + jt + '.',
          rejected: 'Update: your application for ' + jt + ' was not shortlisted.',
          applied: 'Your application status for ' + jt + ' is now Applied.'
        };
        await supabase.from('notifications').insert({ user_id: stu.user_id, title: 'Application update', message: msgs[b.status] || ('Status: ' + b.status), type: b.status === 'selected' ? 'success' : b.status === 'rejected' ? 'warning' : 'info' });
      }
      if (b.status === 'selected') {
        await supabase.from('students').update({ status: 'placed' }).eq('id', data.student_id);
      }
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      await supabase.from('interviews').delete().eq('application_id', id);
      const { error } = await supabase.from('applications').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API applications error:', err); res.status(500).json({ error: err.message }); }
}
