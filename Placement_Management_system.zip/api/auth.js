import supabase from './db-client.js';
import crypto from 'crypto';

const SECRET = process.env.SUPABASE_SERVICE_ROLE_KEY || 'placement-secret-key';
const SALT = '::placement-salt-v1';

function hashPassword(pw) {
  return crypto.createHash('sha256').update(String(pw) + SALT).digest('hex');
}
function sign(payload) {
  const b = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
  return `${b}.${sig}`;
}
function verify(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 2) throw new Error('Invalid token');
  const [b, sig] = parts;
  const expected = crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
  if (sig !== expected) throw new Error('Invalid token');
  return JSON.parse(Buffer.from(b, 'base64url').toString());
}
function isEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '')); }
function isPhone(p) { return /^[0-9+\-\s]{7,15}$/.test(String(p || '')); }
function sanitize(s) {
  if (typeof s !== 'string') return s;
  return s.replace(/[<>]/g, '').trim().slice(0, 2000);
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const token = (req.headers.authorization || '').replace('Bearer ', '') || req.query.token;
      if (!token) return res.status(401).json({ error: 'No token provided' });
      let payload;
      try { payload = verify(token); } catch { return res.status(401).json({ error: 'Invalid or expired token' }); }
      const { data: user, error } = await supabase.from('users').select('id, name, email, role, phone, created_at').eq('id', payload.id).single();
      if (error || !user) return res.status(401).json({ error: 'User not found' });
      return res.status(200).json({ user });
    }

    if (req.method === 'POST') {
      const { action } = req.body || {};

      if (action === 'login') {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
        if (!isEmail(email)) return res.status(400).json({ error: 'Invalid email format' });
        const { data: user, error } = await supabase.from('users').select('*').eq('email', String(email).toLowerCase().trim()).single();
        if (error || !user) return res.status(401).json({ error: 'Invalid email or password' });
        if (user.password !== hashPassword(password)) return res.status(401).json({ error: 'Invalid email or password' });
        const token = sign({ id: user.id, email: user.email, role: user.role, ts: Date.now() });
        return res.status(200).json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone } });
      }

      if (action === 'register') {
        let { name, email, password, phone, department, year, cgpa, skills } = req.body || {};
        name = sanitize(name); email = String(email || '').toLowerCase().trim();
        if (!name) return res.status(400).json({ error: 'Full name is required' });
        if (!email || !isEmail(email)) return res.status(400).json({ error: 'A valid email is required' });
        if (!password || String(password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
        if (phone && !isPhone(phone)) return res.status(400).json({ error: 'Invalid phone number' });
        if (cgpa !== undefined && cgpa !== '' && (isNaN(Number(cgpa)) || Number(cgpa) < 0 || Number(cgpa) > 10)) return res.status(400).json({ error: 'CGPA must be between 0 and 10' });
        const { data: existing } = await supabase.from('users').select('id').eq('email', email).single();
        if (existing) return res.status(409).json({ error: 'An account with this email already exists' });
        const { data: newUser, error: uErr } = await supabase.from('users').insert({ name, email, password: hashPassword(password), role: 'student', phone: phone || null }).select('id, name, email, role, phone').single();
        if (uErr) throw uErr;
        const studentId = 'STU' + new Date().getFullYear() + String(newUser.id).padStart(3, '0');
        const { data: student, error: sErr } = await supabase.from('students').insert({
          user_id: newUser.id, student_id: studentId, name, email, phone: phone || null,
          department: department || 'CSE', year: year || '3rd', cgpa: cgpa === '' ? null : Number(cgpa) || null,
          skills: skills || null, status: 'active'
        }).select().single();
        if (sErr) throw sErr;
        await supabase.from('notifications').insert({ user_id: newUser.id, title: 'Welcome to Placement Portal', message: 'Hi ' + name + '! Your student account (' + studentId + ') has been created. Complete your profile and upload your resume to start applying.', type: 'success' });
        const token = sign({ id: newUser.id, email: newUser.email, role: newUser.role, ts: Date.now() });
        return res.status(201).json({ token, user: newUser, student });
      }

      return res.status(400).json({ error: 'Unknown action' });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API auth error:', err);
    res.status(500).json({ error: err.message });
  }
}
