import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { search, industry, page = '1', limit = '50', id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('companies').select('*').eq('id', id).single();
        if (error) throw error;
        const { data: jobs } = await supabase.from('jobs').select('id, title, status, openings').eq('company_id', id);
        return res.status(200).json({ ...(data || {}), jobs: jobs || [] });
      }
      let q = supabase.from('companies').select('*', { count: 'exact' }).order('id', { ascending: true });
      if (industry) q = q.eq('industry', industry);
      if (search) {
        const s = '%' + String(search).trim() + '%';
        q = q.or('name.ilike.' + s + ',industry.ilike.' + s + ',location.ilike.' + s + ',description.ilike.' + s);
      }
      const pg = Math.max(1, parseInt(page));
      const lim = Math.min(100, Math.max(1, parseInt(limit)));
      q = q.range((pg - 1) * lim, pg * lim - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      const { data: allJobs } = await supabase.from('jobs').select('company_id, status');
      const counts = {};
      (allJobs || []).forEach(j => { if (j.status === 'open') counts[j.company_id] = (counts[j.company_id] || 0) + 1; });
      const enriched = (data || []).map(c => ({ ...c, open_jobs: counts[c.id] || 0 }));
      return res.status(200).json({ data: enriched, total: count || 0, page: pg, limit: lim });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.name || !String(b.name).trim()) return res.status(400).json({ error: 'Company name is required' });
      const row = {
        name: String(b.name).trim(), industry: b.industry || null, website: b.website || null,
        location: b.location || null, description: b.description || null, logo_url: b.logo_url || null,
        contact_email: b.contact_email || null, contact_phone: b.contact_phone || null
      };
      if (row.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.contact_email)) return res.status(400).json({ error: 'Invalid contact email' });
      const { data, error } = await supabase.from('companies').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      const patch = {};
      ['name', 'industry', 'website', 'location', 'description', 'logo_url', 'contact_email', 'contact_phone'].forEach(k => { if (b[k] !== undefined) patch[k] = b[k]; });
      if (patch.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(patch.contact_email)) return res.status(400).json({ error: 'Invalid contact email' });
      const { data, error } = await supabase.from('companies').update(patch).eq('id', b.id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data: jobs } = await supabase.from('jobs').select('id').eq('company_id', id);
      const jobIds = (jobs || []).map(j => j.id);
      if (jobIds.length) {
        await supabase.from('applications').delete().in('job_id', jobIds);
        await supabase.from('interviews').delete().in('job_id', jobIds);
        await supabase.from('jobs').delete().eq('company_id', id);
      }
      const { error } = await supabase.from('companies').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API companies error:', err); res.status(500).json({ error: err.message }); }
}
