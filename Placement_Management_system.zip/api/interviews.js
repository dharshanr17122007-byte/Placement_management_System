import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { student_id, job_id, application_id, upcoming, id } = req.query;
      const { data: jobs } = await supabase.from('jobs').select('*');
      const { data: students } = await supabase.from('students').select('*');
      const { data: companies } = await supabase.from('companies').select('*');
      const jmap = {}; (jobs || []).forEach(j => { jmap[j.id] = j; });
      const smap = {}; (students || []).forEach(s => { smap[s.id] = s; });
      const cmap = {}; (companies || []).forEach(c => { cmap[c.id] = c; });
      let q = supabase.from('interviews').select('*').order('scheduled_at', { ascending: true });
      if (student_id) q = q.eq('student_id', student_id);
      if (job_id) q = q.eq('job_id', job_id);
      if (application_id) q = q.eq('application_id', application_id);
      if (id) q = q.eq('id', id);
      if (upcoming === 'true') q = q.gte('scheduled_at', new Date().toISOString());
      const { data, error } = await q;
      if (error) throw error;
      const enriched = (data || []).map(iv => {
        const job = jmap[iv.job_id];
        return { ...iv, job: job || null, student: smap[iv.student_id] || null, company: job ? (cmap[job.company_id] || null) : null };
      });
      if (id) return res.status(200).json(enriched[0] || null);
      return res.status(200).json(enriched);
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.student_id) return res.status(400).json({ error: 'student_id is required' });
      if (!b.job_id) return res.status(400).json({ error: 'job_id is required' });
      if (!b.scheduled_at) return res.status(400).json({ error: 'Scheduled date & time is required' });
      if (!b.round_name) return res.status(400).json({ error: 'Round name is required' });
      const row = {
        application_id: b.application_id || null, job_id: b.job_id, student_id: b.student_id,
        round_name: b.round_name, scheduled_at: b.scheduled_at, venue: b.venue || null,
        mode: b.mode || 'Offline', interviewer: b.interviewer || null, result: b.result || 'scheduled', notes: b.notes || null
      };
      const { data, error } = await supabase.from('interviews').insert(row).select().single();
      if (error) throw error;
      const { data: stu } = await supabase.from('students').select('user_id').eq('id', b.student_id).single();
      const { data: job } = await supabase.from('jobs').select('title').eq('id', b.job_id).single();
      if (stu?.user_id) {
        await supabase.from('notifications').insert({ user_id: stu.user_id, title: 'Interview scheduled', message: row.round_name + ' interview for ' + (job?.title || 'job') + ' on ' + new Date(row.scheduled_at).toLocaleString() + ' at ' + (row.venue || row.mode) + '.', type: 'info' });
      }
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      const patch = {};
      ['application_id', 'job_id', 'student_id', 'round_name', 'scheduled_at', 'venue', 'mode', 'interviewer', 'result', 'notes'].forEach(k => { if (b[k] !== undefined) patch[k] = b[k]; });
      const { data, error } = await supabase.from('interviews').update(patch).eq('id', b.id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('interviews').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API interviews error:', err); res.status(500).json({ error: err.message }); }
}
