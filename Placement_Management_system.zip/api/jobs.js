import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { search, company_id, status, job_type, page = '1', limit = '50', id } = req.query;
      const { data: companies } = await supabase.from('companies').select('*');
      const cmap = {};
      (companies || []).forEach(c => { cmap[c.id] = c; });
      if (id) {
        const { data, error } = await supabase.from('jobs').select('*').eq('id', id).single();
        if (error) throw error;
        const { count } = await supabase.from('applications').select('id', { count: 'exact', head: true }).eq('job_id', id);
        return res.status(200).json({ ...data, company: cmap[data.company_id] || null, applications_count: count || 0 });
      }
      let q = supabase.from('jobs').select('*', { count: 'exact' }).order('id', { ascending: false });
      if (company_id) q = q.eq('company_id', company_id);
      if (status) q = q.eq('status', status);
      if (job_type) q = q.eq('job_type', job_type);
      if (search) {
        const s = '%' + String(search).trim() + '%';
        q = q.or('title.ilike.' + s + ',description.ilike.' + s + ',location.ilike.' + s);
      }
      const pg = Math.max(1, parseInt(page));
      const lim = Math.min(100, Math.max(1, parseInt(limit)));
      q = q.range((pg - 1) * lim, pg * lim - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      const { data: apps } = await supabase.from('applications').select('job_id');
      const acount = {};
      (apps || []).forEach(a => { acount[a.job_id] = (acount[a.job_id] || 0) + 1; });
      const enriched = (data || []).map(j => ({ ...j, company: cmap[j.company_id] || null, applications_count: acount[j.id] || 0 }));
      return res.status(200).json({ data: enriched, total: count || 0, page: pg, limit: lim });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.company_id) return res.status(400).json({ error: 'Company is required' });
      if (!b.title || !String(b.title).trim()) return res.status(400).json({ error: 'Job title is required' });
      if (b.min_cgpa !== undefined && b.min_cgpa !== null && b.min_cgpa !== '' && (isNaN(Number(b.min_cgpa)) || Number(b.min_cgpa) < 0 || Number(b.min_cgpa) > 10)) return res.status(400).json({ error: 'Min CGPA must be between 0 and 10' });
      if (b.openings !== undefined && (isNaN(Number(b.openings)) || Number(b.openings) < 1)) return res.status(400).json({ error: 'Openings must be at least 1' });
      const row = {
        company_id: b.company_id, title: String(b.title).trim(), description: b.description || null,
        department: b.department || 'All', min_cgpa: (b.min_cgpa === '' || b.min_cgpa === undefined) ? 0 : Number(b.min_cgpa),
        location: b.location || null, job_type: b.job_type || 'Full-time',
        package_lpa: (b.package_lpa === '' || b.package_lpa === undefined) ? null : Number(b.package_lpa),
        openings: b.openings ? Number(b.openings) : 1, deadline: b.deadline || null,
        status: b.status || 'open', created_by: b.created_by || null
      };
      const { data, error } = await supabase.from('jobs').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      const patch = {};
      ['company_id', 'title', 'description', 'department', 'location', 'job_type', 'deadline', 'status', 'created_by'].forEach(k => { if (b[k] !== undefined) patch[k] = b[k]; });
      if (b.min_cgpa !== undefined) patch.min_cgpa = (b.min_cgpa === '' || b.min_cgpa === null) ? 0 : Number(b.min_cgpa);
      if (b.package_lpa !== undefined) patch.package_lpa = (b.package_lpa === '' || b.package_lpa === null) ? null : Number(b.package_lpa);
      if (b.openings !== undefined) patch.openings = Number(b.openings);
      const { data, error } = await supabase.from('jobs').update(patch).eq('id', b.id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      await supabase.from('applications').delete().eq('job_id', id);
      await supabase.from('interviews').delete().eq('job_id', id);
      const { error } = await supabase.from('jobs').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API jobs error:', err); res.status(500).json({ error: err.message }); }
}
