import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id, unread } = req.query;
      let q = supabase.from('notifications').select('*').order('id', { ascending: false }).limit(50);
      if (user_id) q = q.eq('user_id', user_id);
      if (unread === 'true') q = q.eq('is_read', false);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.user_id) return res.status(400).json({ error: 'user_id is required' });
      if (!b.title || !b.message) return res.status(400).json({ error: 'title and message are required' });
      const { data, error } = await supabase.from('notifications').insert({ user_id: b.user_id, title: b.title, message: b.message, type: b.type || 'info' }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (b.mark_all_read && b.user_id) {
        const { error } = await supabase.from('notifications').update({ is_read: true }).eq('user_id', b.user_id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('notifications').update({ is_read: b.is_read !== undefined ? b.is_read : true }).eq('id', b.id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('notifications').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API notifications error:', err); res.status(500).json({ error: err.message }); }
}
