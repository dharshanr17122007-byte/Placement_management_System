import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const [sC, cC, jC, aC] = await Promise.all([
      supabase.from('students').select('id', { count: 'exact', head: true }),
      supabase.from('companies').select('id', { count: 'exact', head: true }),
      supabase.from('jobs').select('id', { count: 'exact', head: true }),
      supabase.from('applications').select('id', { count: 'exact', head: true })
    ]);
    const { data: students } = await supabase.from('students').select('id, department, status, cgpa');
    const { data: applications } = await supabase.from('applications').select('id, status, student_id, job_id, applied_at');
    const { data: jobs } = await supabase.from('jobs').select('id, company_id, title, openings, status');
    const { data: companies } = await supabase.from('companies').select('id, name, industry');
    const { data: interviews } = await supabase.from('interviews').select('id, result, scheduled_at');

    const apps = applications || [];
    const selected = apps.filter(a => a.status === 'selected').length;
    const shortlisted = apps.filter(a => a.status === 'shortlisted').length;
    const rejected = apps.filter(a => a.status === 'rejected').length;
    const applied = apps.filter(a => a.status === 'applied').length;
    const placedStudentIds = new Set(apps.filter(a => a.status === 'selected').map(a => a.student_id));
    const placedCount = placedStudentIds.size;
    const eligible = (students || []).filter(s => s.cgpa === null || Number(s.cgpa) >= 6.0).length;
    const appliedStudentIds = new Set(apps.map(a => a.student_id));
    const placementPct = (students?.length || 0) ? Math.round((placedCount / students.length) * 1000) / 10 : 0;
    const openJobs = (jobs || []).filter(j => j.status === 'open').length;
    const totalOpenings = (jobs || []).filter(j => j.status === 'open').reduce((s, j) => s + (Number(j.openings) || 0), 0);
    const now = new Date();
    const upcomingInterviews = (interviews || []).filter(i => new Date(i.scheduled_at) >= now && i.result === 'scheduled').length;

    const depts = {};
    (students || []).forEach(s => {
      const d = s.department || 'Other';
      if (!depts[d]) depts[d] = { department: d, total: 0, placed: 0, applied: 0 };
      depts[d].total += 1;
      if (placedStudentIds.has(s.id)) depts[d].placed += 1;
      if (appliedStudentIds.has(s.id)) depts[d].applied += 1;
    });
    const departmentWise = Object.values(depts).map(d => ({ ...d, percentage: d.total ? Math.round((d.placed / d.total) * 1000) / 10 : 0 }));

    const cmap = {}; (companies || []).forEach(c => { cmap[c.id] = c.name; });
    const jmap = {}; (jobs || []).forEach(j => { jmap[j.id] = j.company_id; });
    const cw = {};
    apps.forEach(a => {
      const cid = jmap[a.job_id];
      const name = cmap[cid] || 'Unknown';
      if (!cw[name]) cw[name] = { company: name, applications: 0, selected: 0, shortlisted: 0 };
      cw[name].applications += 1;
      if (a.status === 'selected') cw[name].selected += 1;
      if (a.status === 'shortlisted') cw[name].shortlisted += 1;
    });
    const companyWise = Object.values(cw).sort((a, b) => b.applications - a.applications).slice(0, 10);

    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(); d.setMonth(d.getMonth() - i);
      months.push({ month: d.toLocaleString('en', { month: 'short' }), year: d.getFullYear(), applications: 0, selected: 0 });
    }
    apps.forEach(a => {
      if (!a.applied_at) return;
      const d = new Date(a.applied_at);
      const key = d.toLocaleString('en', { month: 'short' });
      const m = months.find(m => m.month === key && m.year === d.getFullYear());
      if (m) { m.applications += 1; if (a.status === 'selected') m.selected += 1; }
    });

    const statusBreakdown = [
      { name: 'Applied', value: applied },
      { name: 'Shortlisted', value: shortlisted },
      { name: 'Selected', value: selected },
      { name: 'Rejected', value: rejected }
    ];

    const topRecruiters = [...companyWise].sort((a, b) => b.selected - a.selected).slice(0, 5);

    return res.status(200).json({
      totals: {
        students: sC.count || 0, companies: cC.count || 0, jobs: jC.count || 0,
        applications: aC.count || 0, selected, shortlisted, rejected,
        placed: placedCount, eligible, appliedStudents: appliedStudentIds.size,
        placementPct, openJobs, totalOpenings, upcomingInterviews
      },
      departmentWise, companyWise, monthly: months, statusBreakdown, topRecruiters
    });
  } catch (err) { console.error('API reports error:', err); res.status(500).json({ error: err.message }); }
}
