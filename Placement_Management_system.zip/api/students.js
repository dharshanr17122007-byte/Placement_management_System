import supabase from './db-client.js';

function isEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '')); }
function isPhone(p) { return /^[0-9+\-\s]{7,15}$/.test(String(p || '')); }

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { search, department, year, status, user_id, page = '1', limit = '50', id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('students').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      let q = supabase.from('students').select('*', { count: 'exact' }).order('id', { ascending: true });
      if (department) q = q.eq('department', department);
      if (year) q = q.eq('year', year);
      if (status) q = q.eq('status', status);
      if (user_id) q = q.eq('user_id', user_id);
      if (search) {
        const s = '%' + String(search).trim() + '%';
        q = q.or('name.ilike.' + s + ',email.ilike.' + s + ',student_id.ilike.' + s + ',skills.ilike.' + s + ',phone.ilike.' + s);
      }
      const pg = Math.max(1, parseInt(page));
      const lim = Math.min(100, Math.max(1, parseInt(limit)));
      q = q.range((pg - 1) * lim, pg * lim - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      return res.status(200).json({ data: data || [], total: count || 0, page: pg, limit: lim });
    }
    if (req.method === 'POST') {
      const b = req.body || {};
      if (!b.name || !String(b.name).trim()) return res.status(400).json({ error: 'Student name is required' });
      if (!b.email || !isEmail(b.email)) return res.status(400).json({ error: 'Valid email is required' });
      if (b.phone && !isPhone(b.phone)) return res.status(400).json({ error: 'Invalid phone number' });
      if (b.cgpa !== undefined && b.cgpa !== null && b.cgpa !== '' && (isNaN(Number(b.cgpa)) || Number(b.cgpa) < 0 || Number(b.cgpa) > 10)) return res.status(400).json({ error: 'CGPA must be between 0 and 10' });
      if (!b.department) return res.status(400).json({ error: 'Department is required' });
      if (!b.year) return res.status(400).json({ error: 'Year is required' });
      const email = String(b.email).toLowerCase().trim();
      const { data: dup } = await supabase.from('students').select('id').eq('email', email).limit(1);
      if (dup && dup.length) return res.status(409).json({ error: 'A student with this email already exists' });
      let student_id = b.student_id;
      if (!student_id) {
        const { count } = await supabase.from('students').select('id', { count: 'exact', head: true });
        student_id = 'STU' + new Date().getFullYear() + String((count || 0) + 1).padStart(3, '0');
      }
      const row = {
        user_id: b.user_id || null, student_id, name: String(b.name).trim(), email,
        phone: b.phone || null, department: b.department, year: b.year,
        cgpa: (b.cgpa === '' || b.cgpa === undefined) ? null : Number(b.cgpa),
        skills: b.skills || null, resume_url: b.resume_url || null, status: b.status || 'active'
      };
      const { data, error } = await supabase.from('students').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const b = req.body || {};
      if (!b.id) return res.status(400).json({ error: 'id is required' });
      if (b.email && !isEmail(b.email)) return res.status(400).json({ error: 'Valid email is required' });
      if (b.phone && !isPhone(b.phone)) return res.status(400).json({ error: 'Invalid phone number' });
      if (b.cgpa !== undefined && b.cgpa !== null && b.cgpa !== '' && (isNaN(Number(b.cgpa)) || Number(b.cgpa) < 0 || Number(b.cgpa) > 10)) return res.status(400).json({ error: 'CGPA must be between 0 and 10' });
      const patch = {};
      ['name', 'email', 'phone', 'department', 'year', 'skills', 'resume_url', 'status', 'student_id', 'user_id'].forEach(k => { if (b[k] !== undefined) patch[k] = b[k]; });
      if (b.cgpa !== undefined) patch.cgpa = (b.cgpa === '' || b.cgpa === null) ? null : Number(b.cgpa);
      if (patch.email) patch.email = String(patch.email).toLowerCase().trim();
      const { data, error } = await supabase.from('students').update(patch).eq('id', b.id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      await supabase.from('applications').delete().eq('student_id', id);
      await supabase.from('interviews').delete().eq('student_id', id);
      const { error } = await supabase.from('students').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API students error:', err); res.status(500).json({ error: err.message }); }
}
