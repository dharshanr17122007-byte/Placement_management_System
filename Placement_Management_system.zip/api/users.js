import supabase from './db-client.js';
import crypto from 'crypto';
const SALT = '::placement-salt-v1';
function hashPassword(pw) { return crypto.createHash('sha256').update(String(pw) + SALT).digest('hex'); }
function isEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '')); }

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { role, search } = req.query;
      let q = supabase.from('users').select('id, name, email, role, phone, created_at').order('id', { ascending: true });
      if (role) q = q.eq('role', role);
      const { data, error } = await q;
      if (error) throw error;
      let out = data || [];
      if (search) {
        const s = String(search).toLowerCase();
        out = out.filter(u => (u.name || '').toLowerCase().includes(s) || (u.email || '').toLowerCase().includes(s));
      }
      return res.status(200).json(out);
    }
    if (req.method === 'POST') {
      const { name, email, password, role, phone } = req.body || {};
      if (!name || !String(name).trim()) return res.status(400).json({ error: 'Name is required' });
      if (!email || !isEmail(email)) return res.status(400).json({ error: 'Valid email is required' });
      if (!password || String(password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
      if (!['admin', 'officer', 'student'].includes(role)) return res.status(400).json({ error: 'Role must be admin, officer or student' });
      const em = String(email).toLowerCase().trim();
      const { data: ex } = await supabase.from('users').select('id').eq('email', em).single();
      if (ex) return res.status(409).json({ error: 'Email already exists' });
      const { data, error } = await supabase.from('users').insert({ name: String(name).trim(), email: em, password: hashPassword(password), role, phone: phone || null }).select('id, name, email, role, phone, created_at').single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, name, phone, role, password } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const patch = {};
      if (name !== undefined) patch.name = String(name).trim();
      if (phone !== undefined) patch.phone = phone;
      if (role !== undefined) {
        if (!['admin', 'officer', 'student'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
        patch.role = role;
      }
      if (password) {
        if (String(password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
        patch.password = hashPassword(password);
      }
      const { data, error } = await supabase.from('users').update(patch).eq('id', id).select('id, name, email, role, phone, created_at').single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const id = req.body?.id || req.query.id;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('users').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { console.error('API users error:', err); res.status(500).json({ error: err.message }); }
}
