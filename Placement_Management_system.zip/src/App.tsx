import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider } from './components/Toast';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminDashboard from './pages/AdminDashboard';
import OfficerDashboard from './pages/OfficerDashboard';
import StudentDashboard from './pages/StudentDashboard';
import Students from './pages/Students';
import Companies from './pages/Companies';
import Jobs from './pages/Jobs';
import Applications from './pages/Applications';
import Interviews from './pages/Interviews';
import Reports from './pages/Reports';
import Users from './pages/Users';
import Profile from './pages/Profile';

function RoleHome() {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-9 h-9 border-4 border-slate-200 border-t-[#0b1f4b] rounded-full animate-spin" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={user.role === 'admin' ? '/admin' : user.role === 'officer' ? '/officer' : '/student'} replace />;
}

function Shell({ children }: { children: React.ReactNode }) {
  return <Layout>{children}</Layout>;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<RoleHome />} />
            <Route path="/admin" element={<ProtectedRoute roles={['admin']}><Shell><AdminDashboard /></Shell></ProtectedRoute>} />
            <Route path="/officer" element={<ProtectedRoute roles={['officer', 'admin']}><Shell><OfficerDashboard /></Shell></ProtectedRoute>} />
            <Route path="/student" element={<ProtectedRoute roles={['student']}><Shell><StudentDashboard /></Shell></ProtectedRoute>} />
            <Route path="/students" element={<ProtectedRoute roles={['admin', 'officer']}><Shell><Students /></Shell></ProtectedRoute>} />
            <Route path="/companies" element={<ProtectedRoute roles={['admin', 'officer', 'student']}><Shell><Companies /></Shell></ProtectedRoute>} />
            <Route path="/jobs" element={<ProtectedRoute roles={['admin', 'officer', 'student']}><Shell><Jobs /></Shell></ProtectedRoute>} />
            <Route path="/applications" element={<ProtectedRoute roles={['admin', 'officer', 'student']}><Shell><Applications /></Shell></ProtectedRoute>} />
            <Route path="/interviews" element={<ProtectedRoute roles={['admin', 'officer', 'student']}><Shell><Interviews /></Shell></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute roles={['admin', 'officer']}><Shell><Reports /></Shell></ProtectedRoute>} />
            <Route path="/users" element={<ProtectedRoute roles={['admin']}><Shell><Users /></Shell></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute roles={['admin', 'officer', 'student']}><Shell><Profile /></Shell></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
