// Lightweight SVG charts (no external deps)
export function BarChart({ data, height = 220 }: { data: { label: string; value: number; value2?: number }[]; height?: number }) {
  const max = Math.max(1, ...data.map(d => Math.max(d.value, d.value2 || 0)));
  return (
    <div className="w-full overflow-x-auto">
      <div className="flex items-end gap-3 min-w-[280px]" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1.5 min-w-[36px]">
            <div className="flex items-end gap-1 h-full w-full justify-center" style={{ height: height - 44 }}>
              <div className="w-full max-w-[34px] rounded-t-lg bg-gradient-to-t from-[#0b1f4b] to-sky-500 transition-all" style={{ height: `${(d.value / max) * 100}%`, minHeight: d.value ? 4 : 0 }} title={`${d.label}: ${d.value}`} />
              {d.value2 !== undefined && <div className="w-full max-w-[34px] rounded-t-lg bg-gradient-to-t from-emerald-600 to-emerald-300 transition-all" style={{ height: `${(d.value2 / max) * 100}%`, minHeight: d.value2 ? 4 : 0 }} title={`${d.label}: ${d.value2}`} />}
            </div>
            <span className="text-[11px] font-semibold text-slate-500 truncate max-w-full">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function DonutChart({ data, size = 190 }: { data: { name: string; value: number; color: string }[]; size?: number }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  let acc = 0;
  const R = 70, C = 2 * Math.PI * R;
  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <svg width={size} height={size} viewBox="0 0 180 180" className="-rotate-90">
        <circle cx="90" cy="90" r={R} fill="none" stroke="#f1f5f9" strokeWidth="26" />
        {data.map((d, i) => {
          const frac = d.value / total;
          const el = <circle key={i} cx="90" cy="90" r={R} fill="none" stroke={d.color} strokeWidth="26" strokeDasharray={`${frac * C} ${C}`} strokeDashoffset={-acc * C} strokeLinecap="butt" />;
          acc += frac;
          return el;
        })}
        <text x="90" y="84" textAnchor="middle" className="fill-slate-900" fontSize="26" fontWeight="800" transform="rotate(90 90 90)">{total}</text>
        <text x="90" y="104" textAnchor="middle" className="fill-slate-500" fontSize="11" transform="rotate(90 90 90)">Total</text>
      </svg>
      <div className="space-y-2.5 flex-1 w-full">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2.5 text-sm">
            <span className="w-3.5 h-3.5 rounded-md shrink-0" style={{ background: d.color }} />
            <span className="font-medium text-slate-700 flex-1">{d.name}</span>
            <span className="font-bold text-slate-900">{d.value}</span>
            <span className="text-xs text-slate-400 w-11 text-right">{Math.round((d.value / total) * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function HBar({ label, value, max, color }: { label: string; value: number; max: number; color?: string }) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm mb-1"><span className="font-semibold text-slate-700">{label}</span><span className="font-bold text-slate-900">{value}</span></div>
      <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden"><div className="h-full rounded-full transition-all" style={{ width: `${max ? (value / max) * 100 : 0}%`, background: color || '#0b1f4b' }} /></div>
    </div>
  );
}

export function ProgressRing({ pct, size = 120 }: { pct: number; size?: number }) {
  const R = 52, C = 2 * Math.PI * R;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox="0 0 120 120" className="-rotate-90">
        <circle cx="60" cy="60" r={R} fill="none" stroke="#e2e8f0" strokeWidth="12" />
        <circle cx="60" cy="60" r={R} fill="none" stroke="url(#pgrad)" strokeWidth="12" strokeLinecap="round" strokeDasharray={`${(Math.min(100, pct) / 100) * C} ${C}`} />
        <defs><linearGradient id="pgrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#f59e0b" /><stop offset="100%" stopColor="#0b1f4b" /></linearGradient></defs>
      </svg>
      <div className="absolute text-center"><p className="text-2xl font-extrabold text-slate-900">{pct}%</p><p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Placed</p></div>
    </div>
  );
}
