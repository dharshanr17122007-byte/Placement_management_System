import { useState, useEffect, ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, Building2, Briefcase, FileCheck2, CalendarClock, BarChart3, UserCog, GraduationCap, Bell, LogOut, Menu, X, Search, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../lib/api';
import { initials } from '../lib/utils';

const NAV: Record<string, { to: string; label: string; icon: any }[]> = {
  admin: [
    { to: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/students', label: 'Students', icon: GraduationCap },
    { to: '/companies', label: 'Companies', icon: Building2 },
    { to: '/jobs', label: 'Jobs', icon: Briefcase },
    { to: '/applications', label: 'Applications', icon: FileCheck2 },
    { to: '/interviews', label: 'Interviews', icon: CalendarClock },
    { to: '/reports', label: 'Reports', icon: BarChart3 },
    { to: '/users', label: 'Users & Officers', icon: UserCog },
  ],
  officer: [
    { to: '/officer', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/students', label: 'Students', icon: GraduationCap },
    { to: '/companies', label: 'Companies', icon: Building2 },
    { to: '/jobs', label: 'Jobs', icon: Briefcase },
    { to: '/applications', label: 'Applications', icon: FileCheck2 },
    { to: '/interviews', label: 'Interviews', icon: CalendarClock },
    { to: '/reports', label: 'Reports', icon: BarChart3 },
  ],
  student: [
    { to: '/student', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/jobs', label: 'Browse Jobs', icon: Briefcase },
    { to: '/applications', label: 'My Applications', icon: FileCheck2 },
    { to: '/interviews', label: 'Interviews', icon: CalendarClock },
    { to: '/companies', label: 'Companies', icon: Building2 },
  ],
};

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const loc = useLocation();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const [notifs, setNotifs] = useState<any[]>([]);
  const [showN, setShowN] = useState(false);
  const [showU, setShowU] = useState(false);
  const role = user?.role || 'student';
  const items = NAV[role] || NAV.student;

  const loadNotifs = async () => {
    if (!user) return;
    try { const d = await api.get(`/api/notifications?user_id=${user.id}`); setNotifs(d || []); } catch {}
  };
  useEffect(() => { loadNotifs(); const t = setInterval(loadNotifs, 30000); return () => clearInterval(t); }, [user?.id]);
  const unread = notifs.filter(n => !n.is_read).length;
  const markAll = async () => { if (!user) return; await api.put('/api/notifications', { mark_all_read: true, user_id: user.id }); loadNotifs(); };

  const roleLabel = role === 'admin' ? 'Administrator' : role === 'officer' ? 'Placement Officer' : 'Student';

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className={`fixed lg:static z-40 h-screen w-64 bg-[#0b1f4b] text-white flex-col transition-transform duration-300 flex ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="px-5 py-5 flex items-center gap-3 border-b border-white/10">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shrink-0"><GraduationCap className="w-6 h-6 text-[#0b1f4b]" /></div>
          <div><p className="font-bold text-[15px] leading-tight">Placement Portal</p><p className="text-[11px] text-white/60">College Career Cell</p></div>
        </div>
        <div className="px-4 py-3"><span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider bg-white/10 text-amber-300 px-2.5 py-1 rounded-full"><span className="w-1.5 h-1.5 rounded-full bg-amber-400" />{roleLabel}</span></div>
        <nav className="flex-1 overflow-y-auto px-3 pb-4 space-y-1">
          {items.map(it => {
            const active = loc.pathname === it.to;
            const Icon = it.icon;
            return <Link key={it.to} to={it.to} onClick={() => setOpen(false)} className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition ${active ? 'bg-amber-400 text-[#0b1f4b] shadow' : 'text-white/75 hover:bg-white/10 hover:text-white'}`}><Icon className="w-[18px] h-[18px]" />{it.label}</Link>;
          })}
        </nav>
        <div className="p-4 border-t border-white/10">
          <div className="bg-white/5 rounded-xl p-3 mb-3"><p className="text-xs text-white/70">Need help?</p><p className="text-xs font-semibold text-white">placement@college.edu</p></div>
          <button onClick={() => { logout(); nav('/'); }} className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl text-sm font-semibold bg-white/10 hover:bg-rose-500/80 transition"><LogOut className="w-4 h-4" />Sign out</button>
        </div>
      </aside>
      {open && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setOpen(false)} />}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center gap-3">
          <button className="lg:hidden p-2 rounded-lg hover:bg-slate-100" onClick={() => setOpen(!open)}>{open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}</button>
          <div className="hidden md:flex items-center gap-2 bg-slate-100 rounded-xl px-3 py-2 flex-1 max-w-md"><Search className="w-4 h-4 text-slate-400" /><input placeholder="Quick search… (press Enter)" className="bg-transparent outline-none text-sm w-full" onKeyDown={(e) => { if (e.key === 'Enter') { const q = (e.target as HTMLInputElement).value; nav(role === 'student' ? `/jobs?search=${encodeURIComponent(q)}` : `/students?search=${encodeURIComponent(q)}`); } }} /></div>
          <div className="flex-1 md:hidden" />
          <div className="relative">
            <button onClick={() => { setShowN(!showN); setShowU(false); }} className="relative p-2.5 rounded-xl hover:bg-slate-100 transition"><Bell className="w-5 h-5 text-slate-600" />{unread > 0 && <span className="absolute -top-0.5 -right-0.5 min-w-[20px] h-5 px-1 rounded-full bg-rose-500 text-white text-[11px] font-bold flex items-center justify-center">{unread}</span>}</button>
            {showN && (
              <div className="absolute right-0 mt-2 w-80 max-w-[90vw] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50">
                <div className="px-4 py-3 border-b flex items-center justify-between"><p className="font-bold text-sm">Notifications</p><button onClick={markAll} className="text-xs font-semibold text-sky-600 hover:underline">Mark all read</button></div>
                <div className="max-h-80 overflow-y-auto">{notifs.length === 0 ? <p className="p-5 text-sm text-slate-500 text-center">No notifications yet</p> : notifs.map(n => (
                  <div key={n.id} className={`px-4 py-3 border-b last:border-0 ${n.is_read ? '' : 'bg-sky-50/60'}`}><p className="text-sm font-semibold text-slate-800">{n.title}</p><p className="text-xs text-slate-600 mt-0.5">{n.message}</p></div>
                ))}</div>
              </div>
            )}
          </div>
          <div className="relative">
            <button onClick={() => { setShowU(!showU); setShowN(false); }} className="flex items-center gap-2.5 p-1.5 pr-2.5 rounded-xl hover:bg-slate-100 transition">
              <span className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0b1f4b] to-sky-700 text-white text-xs font-bold flex items-center justify-center">{initials(user?.name || '')}</span>
              <span className="hidden sm:block text-left"><span className="block text-sm font-bold text-slate-800 leading-tight max-w-[140px] truncate">{user?.name}</span><span className="block text-[11px] text-slate-500 capitalize">{role}</span></span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>
            {showU && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden py-1 z-50">
                <Link to="/profile" onClick={() => setShowU(false)} className="block px-4 py-2.5 text-sm hover:bg-slate-50">My Profile</Link>
                <Link to="/" onClick={() => setShowU(false)} className="block px-4 py-2.5 text-sm hover:bg-slate-50">Public site</Link>
                <button onClick={() => { logout(); nav('/'); }} className="w-full text-left px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50">Sign out</button>
              </div>
            )}
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 max-w-[1400px] w-full mx-auto">{children}</main>
      </div>
    </div>
  );
}

export { Users };
