import { Navigate, useLocation } from 'react-router-dom';
import { ReactElement } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function ProtectedRoute({ children, roles }: { children: ReactElement; roles?: string[] }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-slate-50"><div className="flex flex-col items-center gap-3"><div className="w-10 h-10 border-4 border-slate-200 border-t-[#0b1f4b] rounded-full animate-spin" /><p className="text-sm text-slate-500">Loading portal…</p></div></div>;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  if (roles && !roles.includes(user.role)) {
    const home = user.role === 'admin' ? '/admin' : user.role === 'officer' ? '/officer' : '/student';
    return <Navigate to={home} replace />;
  }
  return children;
}
