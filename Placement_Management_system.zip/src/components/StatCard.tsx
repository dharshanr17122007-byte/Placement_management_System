import { LucideIcon } from 'lucide-react';

export default function StatCard({ label, value, sub, icon: Icon, tone, trend }: { label: string; value: string | number; sub?: string; icon: LucideIcon; tone: string; trend?: string }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition relative overflow-hidden">
      <div className={`absolute top-0 left-0 w-1 h-full ${tone}`} />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{label}</p><p className="text-3xl font-extrabold text-slate-900 mt-1">{value}</p>{sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}{trend && <span className="inline-block mt-2 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">{trend}</span>}</div>
        <div className="w-11 h-11 rounded-xl bg-slate-100 flex items-center justify-center shrink-0"><Icon className="w-5 h-5 text-slate-700" /></div>
      </div>
    </div>
  );
}
