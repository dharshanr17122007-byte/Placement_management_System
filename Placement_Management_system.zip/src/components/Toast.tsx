import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';

interface Toast { id: number; message: string; type: 'success' | 'error' | 'info'; }
const Ctx = createContext<{ toast: (msg: string, type?: Toast['type']) => void }>({ toast: () => {} });
export const useToast = () => useContext(Ctx);

let nid = 1;
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toast = useCallback((message: string, type: Toast['type'] = 'success') => {
    const id = nid++;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3800);
  }, []);
  const dismiss = (id: number) => setToasts(prev => prev.filter(t => t.id !== id));
  return (
    <Ctx.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-5 right-5 z-[100] flex flex-col gap-2 max-w-sm w-[calc(100vw-2.5rem)]">
        {toasts.map(t => (
          <div key={t.id} className={`flex items-start gap-3 px-4 py-3 rounded-xl shadow-xl border bg-white toast-in ${t.type === 'success' ? 'border-emerald-200' : t.type === 'error' ? 'border-rose-200' : 'border-sky-200'}`}>
            {t.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5" /> : t.type === 'error' ? <AlertTriangle className="w-5 h-5 text-rose-600 mt-0.5" /> : <Info className="w-5 h-5 text-sky-600 mt-0.5" />}
            <p className="text-sm text-slate-800 flex-1">{t.message}</p>
            <button onClick={() => dismiss(t.id)} className="text-slate-400 hover:text-slate-600"><X className="w-4 h-4" /></button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
