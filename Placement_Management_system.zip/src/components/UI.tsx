import { ReactNode } from 'react';
import { X } from 'lucide-react';
import { statusColor } from '../lib/utils';

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0b1f4b]/60 backdrop-blur-sm" onClick={onClose} />
      <div className={`relative bg-white rounded-2xl shadow-2xl w-full ${wide ? 'max-w-3xl' : 'max-w-lg'} max-h-[90vh] overflow-y-auto toast-in`}>
        <div className="sticky top-0 bg-white px-6 py-4 border-b flex items-center justify-between rounded-t-2xl z-10"><h3 className="font-bold text-lg text-slate-900">{title}</h3><button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100"><X className="w-5 h-5" /></button></div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, onClose, onConfirm, title, message }: { open: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0b1f4b]/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 toast-in">
        <h3 className="font-bold text-lg text-slate-900">{title}</h3>
        <p className="text-sm text-slate-600 mt-2">{message}</p>
        <div className="flex gap-3 mt-5">
          <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold hover:bg-slate-50">Cancel</button>
          <button onClick={() => { onConfirm(); onClose(); }} className="flex-1 px-4 py-2.5 rounded-xl bg-rose-600 text-white text-sm font-semibold hover:bg-rose-700">Delete</button>
        </div>
      </div>
    </div>
  );
}

export function Field({ label, error, children, required }: { label: string; error?: string; children: ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="text-xs font-bold uppercase tracking-wide text-slate-600">{label}{required && <span className="text-rose-500"> *</span>}</span>
      <div className="mt-1.5">{children}</div>
      {error && <span className="text-xs text-rose-600 mt-1 block">{error}</span>}
    </label>
  );
}

export const inputCls = 'w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-[#0b1f4b]/20 focus:border-[#0b1f4b] transition bg-white';

export function Empty({ title, sub }: { title: string; sub?: string }) {
  return <div className="text-center py-12"><div className="w-14 h-14 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-2xl">📭</div><p className="font-bold text-slate-800 mt-3">{title}</p>{sub && <p className="text-sm text-slate-500 mt-1">{sub}</p>}</div>;
}

export function Spinner({ label }: { label?: string }) {
  return <div className="flex flex-col items-center justify-center py-14 gap-3"><div className="w-9 h-9 border-4 border-slate-200 border-t-[#0b1f4b] rounded-full animate-spin" />{label && <p className="text-sm text-slate-500">{label}</p>}</div>;
}

export function Pagination({ page, total, limit, onPage }: { page: number; total: number; limit: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / limit));
  if (pages <= 1) return null;
  const nums: number[] = [];
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) nums.push(i);
  return (
    <div className="flex items-center justify-between mt-4 flex-wrap gap-3">
      <p className="text-xs text-slate-500">Showing {(page - 1) * limit + 1}–{Math.min(page * limit, total)} of {total}</p>
      <div className="flex gap-1.5">
        <button disabled={page <= 1} onClick={() => onPage(page - 1)} className="px-3 py-1.5 rounded-lg border text-sm font-semibold disabled:opacity-40 hover:bg-slate-50">Prev</button>
        {nums.map(n => <button key={n} onClick={() => onPage(n)} className={`px-3 py-1.5 rounded-lg text-sm font-semibold ${n === page ? 'bg-[#0b1f4b] text-white' : 'border hover:bg-slate-50'}`}>{n}</button>)}
        <button disabled={page >= pages} onClick={() => onPage(page + 1)} className="px-3 py-1.5 rounded-lg border text-sm font-semibold disabled:opacity-40 hover:bg-slate-50">Next</button>
      </div>
    </div>
  );
}

export function Badge({ value }: { value: string }) {
  return <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-bold capitalize ring-1 ${statusColor(value)}`}>{value}</span>;
}
