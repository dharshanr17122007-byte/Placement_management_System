import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { api } from '../lib/api';

export interface User { id: number; name: string; email: string; role: string; phone?: string | null; }
interface AuthCtx {
  user: User | null; loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (data: any) => Promise<User>;
  logout: () => void;
  refresh: () => Promise<void>;
}
const Ctx = createContext<AuthCtx>({ user: null, loading: true, login: async () => { throw new Error('not ready'); }, register: async () => { throw new Error('not ready'); }, logout: () => {}, refresh: async () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    const token = localStorage.getItem('pms_token');
    if (!token) { setLoading(false); return; }
    try {
      const data = await api.get('/api/auth');
      setUser(data.user);
    } catch {
      localStorage.removeItem('pms_token');
      setUser(null);
    } finally { setLoading(false); }
  };

  useEffect(() => { refresh(); }, []);

  const login = async (email: string, password: string) => {
    const data = await api.post('/api/auth', { action: 'login', email, password });
    localStorage.setItem('pms_token', data.token);
    setUser(data.user);
    return data.user;
  };
  const register = async (payload: any) => {
    const data = await api.post('/api/auth', { action: 'register', ...payload });
    localStorage.setItem('pms_token', data.token);
    setUser(data.user);
    return data.user;
  };
  const logout = () => { localStorage.removeItem('pms_token'); setUser(null); };

  return <Ctx.Provider value={{ user, loading, login, register, logout, refresh }}>{children}</Ctx.Provider>;
}
export const useAuth = () => useContext(Ctx);
