export function isEmail(e: string) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '')); }
export function isPhone(p: string) { return /^[0-9+\-\s]{7,15}$/.test(String(p || '')); }
export function isCGPA(v: any) {
  if (v === '' || v === null || v === undefined) return true;
  const n = Number(v);
  return !isNaN(n) && n >= 0 && n <= 10;
}
export function formatDate(d: any) {
  if (!d) return '—';
  try { return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); } catch { return String(d); }
}
export function formatDateTime(d: any) {
  if (!d) return '—';
  try { return new Date(d).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch { return String(d); }
}
export function initials(name: string) {
  return String(name || '?').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}
export function statusColor(s: string) {
  const m: Record<string, string> = {
    applied: 'bg-sky-100 text-sky-800 ring-sky-200',
    shortlisted: 'bg-amber-100 text-amber-800 ring-amber-200',
    selected: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
    rejected: 'bg-rose-100 text-rose-800 ring-rose-200',
    withdrawn: 'bg-slate-100 text-slate-700 ring-slate-200',
    open: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
    closed: 'bg-slate-200 text-slate-700 ring-slate-300',
    active: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
    placed: 'bg-violet-100 text-violet-800 ring-violet-200',
    inactive: 'bg-slate-200 text-slate-600 ring-slate-300',
    scheduled: 'bg-sky-100 text-sky-800 ring-sky-200',
    passed: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
    failed: 'bg-rose-100 text-rose-800 ring-rose-200',
  };
  return m[String(s || '').toLowerCase()] || 'bg-slate-100 text-slate-700 ring-slate-200';
}
export function toCSV(rows: any[], cols: { key: string; label: string }[]) {
  const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [cols.map(c => c.label).join(',')];
  rows.forEach(r => lines.push(cols.map(c => esc(typeof r[c.key] === 'object' ? JSON.stringify(r[c.key]) : r[c.key])).join(',')));
  return lines.join('\n');
}
export function downloadCSV(filename: string, csv: string) {
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
export const DEPARTMENTS = ['CSE', 'IT', 'ECE', 'EEE', 'ME', 'CE', 'AIDS', 'MBA', 'MCA'];
export const YEARS = ['1st', '2nd', '3rd', '4th'];
export const INDUSTRIES = ['IT & Software', 'Finance & Banking', 'E-commerce', 'Consulting', 'Manufacturing', 'Healthcare', 'Education', 'Telecom', 'Automobile', 'Other'];
