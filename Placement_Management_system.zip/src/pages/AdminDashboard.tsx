import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, Building2, Briefcase, FileCheck2, BadgeCheck, Percent, Bell, ArrowRight, CalendarClock } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import StatCard from '../components/StatCard';
import { Spinner } from '../components/UI';
import { BarChart, DonutChart, HBar, ProgressRing } from '../components/Charts';
import { formatDateTime } from '../lib/utils';

export default function AdminDashboard() {
  const { user } = useAuth();
  const [rep, setRep] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activity, setActivity] = useState<any[]>([]);
  const [interviews, setInterviews] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([
      api.get('/api/reports'),
      api.get('/api/applications?limit=6'),
      api.get('/api/interviews?upcoming=true'),
    ]).then(([r, a, iv]) => { setRep(r); setActivity(a.data || []); setInterviews((iv || []).slice(0, 5)); })
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner label="Loading admin dashboard…" />;
  const t = rep?.totals || {};

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-[#0b1f4b] to-[#1e4fa3] rounded-3xl p-6 sm:p-8 text-white flex flex-col sm:flex-row sm:items-center gap-4 justify-between overflow-hidden relative">
        <div className="relative z-10">
          <p className="text-amber-300 text-xs font-bold uppercase tracking-widest">Admin Control Center</p>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">Welcome back, {user?.name?.split(' ')[0]} 👋</h1>
          <p className="text-white/70 text-sm mt-1.5">Here's the placement health of your campus today.</p>
        </div>
        <div className="flex gap-3 relative z-10">
          <Link to="/reports" className="px-5 py-2.5 rounded-xl bg-amber-400 text-[#0b1f4b] text-sm font-bold hover:bg-amber-300">View Reports</Link>
          <Link to="/students" className="px-5 py-2.5 rounded-xl border border-white/30 text-sm font-bold hover:bg-white/10">Manage Students</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard label="Students" value={t.students ?? 0} icon={Users} tone="bg-sky-500" sub={`${t.appliedStudents ?? 0} applied`} />
        <StatCard label="Companies" value={t.companies ?? 0} icon={Building2} tone="bg-violet-500" sub={`${t.openJobs ?? 0} open drives`} />
        <StatCard label="Job Openings" value={t.totalOpenings ?? 0} icon={Briefcase} tone="bg-amber-500" sub={`${t.jobs ?? 0} postings`} />
        <StatCard label="Applications" value={t.applications ?? 0} icon={FileCheck2} tone="bg-indigo-500" sub={`${t.shortlisted ?? 0} shortlisted`} />
        <StatCard label="Selected" value={t.selected ?? 0} icon={BadgeCheck} tone="bg-emerald-500" sub={`${t.placed ?? 0} students placed`} />
        <StatCard label="Placement %" value={`${t.placementPct ?? 0}%`} icon={Percent} tone="bg-rose-500" sub={`${t.eligible ?? 0} eligible`} />
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 lg:col-span-1 flex flex-col items-center">
          <p className="font-bold text-slate-800 self-start">Overall Placement Rate</p>
          <div className="py-4"><ProgressRing pct={t.placementPct ?? 0} /></div>
          <p className="text-xs text-slate-500 text-center">{t.placed ?? 0} of {t.students ?? 0} students placed · {t.rejected ?? 0} rejections to review</p>
        </div>
        <div className="bg-white rounded-3xl border border-slate-200 p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">Application Status Breakdown</p><Link to="/applications" className="text-xs font-bold text-sky-600 hover:underline flex items-center gap-1">Manage <ArrowRight className="w-3.5 h-3.5" /></Link></div>
          <DonutChart data={[
            { name: 'Applied', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Applied')?.value || 0, color: '#0ea5e9' },
            { name: 'Shortlisted', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Shortlisted')?.value || 0, color: '#f59e0b' },
            { name: 'Selected', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Selected')?.value || 0, color: '#10b981' },
            { name: 'Rejected', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Rejected')?.value || 0, color: '#f43f5e' },
          ]} />
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">Department-wise Placement</p><Link to="/reports" className="text-xs font-bold text-sky-600 hover:underline">Full report →</Link></div>
          <BarChart data={(rep?.departmentWise || []).map((d: any) => ({ label: d.department, value: d.total, value2: d.placed }))} />
          <div className="flex gap-4 mt-3 text-xs text-slate-500"><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#0b1f4b]" />Total</span><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-500" />Placed</span></div>
        </div>
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <p className="font-bold text-slate-800 mb-4">Top Recruiters (by selections)</p>
          <div className="space-y-4">{(rep?.topRecruiters || []).map((c: any, i: number) => <HBar key={i} label={c.company} value={c.selected} max={Math.max(1, ...(rep?.topRecruiters || []).map((x: any) => x.selected))} color={['#0b1f4b', '#1e4fa3', '#0ea5e9', '#10b981', '#f59e0b'][i % 5]} />)}
            {(!rep?.topRecruiters || rep.topRecruiters.length === 0) && <p className="text-sm text-slate-400 text-center py-6">No selections yet</p>}</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800 flex items-center gap-2"><Bell className="w-4 h-4 text-amber-500" />Recent Applications</p><Link to="/applications" className="text-xs font-bold text-sky-600 hover:underline">View all →</Link></div>
          <div className="space-y-2.5">
            {activity.map(a => (
              <div key={a.id} className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 hover:bg-slate-100 transition">
                <div className="w-10 h-10 rounded-xl bg-[#0b1f4b] text-white text-xs font-bold flex items-center justify-center shrink-0">{(a.student?.name || '?').split(' ').map((w: string) => w[0]).slice(0, 2).join('')}</div>
                <div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{a.student?.name} <span className="font-normal text-slate-500">applied for</span> {a.job?.title}</p><p className="text-xs text-slate-500">{a.company?.name} · {a.student?.department}</p></div>
                <span className="text-[11px] font-bold capitalize px-2.5 py-1 rounded-full bg-sky-100 text-sky-700 shrink-0">{a.status}</span>
              </div>
            ))}
            {activity.length === 0 && <p className="text-sm text-slate-400 text-center py-4">No applications yet</p>}
          </div>
        </div>
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800 flex items-center gap-2"><CalendarClock className="w-4 h-4 text-sky-600" />Upcoming Interviews</p><Link to="/interviews" className="text-xs font-bold text-sky-600 hover:underline">Schedule →</Link></div>
          <div className="space-y-2.5">
            {interviews.map(iv => (
              <div key={iv.id} className="flex items-center gap-3 p-3 rounded-2xl border border-slate-100">
                <div className="w-12 text-center shrink-0 bg-amber-50 rounded-xl py-1.5"><p className="text-lg font-extrabold text-[#0b1f4b] leading-none">{new Date(iv.scheduled_at).getDate()}</p><p className="text-[10px] font-bold text-slate-500 uppercase">{new Date(iv.scheduled_at).toLocaleString('en', { month: 'short' })}</p></div>
                <div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{iv.student?.name} · {iv.round_name}</p><p className="text-xs text-slate-500 truncate">{iv.job?.title} @ {iv.company?.name} · {formatDateTime(iv.scheduled_at)}</p></div>
              </div>
            ))}
            {interviews.length === 0 && <p className="text-sm text-slate-400 text-center py-4">No upcoming interviews</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
