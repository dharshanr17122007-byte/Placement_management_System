import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Download, Trash2, CalendarPlus, X, CheckCircle2, XCircle, Star } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { ConfirmDialog, Field, inputCls, Modal, Empty, Spinner, Pagination, Badge } from '../components/UI';
import { toCSV, downloadCSV, formatDate, formatDateTime, initials } from '../lib/utils';

const STEPS = ['applied', 'shortlisted', 'selected'];

export default function Applications() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sp] = useSearchParams();
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState(sp.get('status') || '');
  const [page, setPage] = useState(1);
  const [del, setDel] = useState<any>(null);
  const [me, setMe] = useState<any>(null);
  const [sched, setSched] = useState<any>(null);
  const [schedForm, setSchedForm] = useState({ round_name: 'Technical Round 1', scheduled_at: '', venue: '', mode: 'Offline', interviewer: '' });
  const isStudent = user?.role === 'student';
  const LIMIT = 12;

  const fetchRows = async (studentId?: number) => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) q.set('search', search);
      if (status) q.set('status', status);
      if (isStudent && (studentId || me?.id)) q.set('student_id', String(studentId || me.id));
      const d = await api.get(`/api/applications?${q.toString()}`);
      setRows(d.data || []); setTotal(d.total || 0);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (isStudent && user) {
      api.get(`/api/students?user_id=${user.id}&limit=1`).then(s => {
        const m = (s.data || [])[0];
        setMe(m || null);
        if (m) fetchRows(m.id);
        else setLoading(false);
      }).catch(() => setLoading(false));
    }
  }, [user?.id]);
  useEffect(() => { if (!isStudent || me) fetchRows(); }, [page, status, me?.id]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); if (!isStudent || me) fetchRows(); }, 450); return () => clearTimeout(t); }, [search]);
  useEffect(() => { const s = sp.get('status'); if (s) setStatus(s); }, []);

  const setStatusOf = async (a: any, st: string) => {
    try {
      await api.put('/api/applications', { id: a.id, status: st });
      toast(`Application ${st}`, 'success');
      fetchRows();
    } catch (e: any) { toast(e.message, 'error'); }
  };
  const remove = async () => {
    try { await api.del(`/api/applications?id=${del.id}`); toast('Application removed', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };
  const withdraw = async (a: any) => {
    try { await api.put('/api/applications', { id: a.id, status: 'withdrawn' }); toast('Application withdrawn', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  const openSched = (a: any) => {
    setSched(a);
    const d = new Date(); d.setDate(d.getDate() + 2); d.setHours(10, 0, 0, 0);
    setSchedForm({ round_name: 'Technical Round 1', scheduled_at: d.toISOString().slice(0, 16), venue: 'Placement Cell, Block A', mode: 'Offline', interviewer: '' });
  };
  const saveSched = async () => {
    if (!schedForm.scheduled_at) { toast('Pick date & time', 'error'); return; }
    try {
      await api.post('/api/interviews', { application_id: sched.id, job_id: sched.job_id, student_id: sched.student_id, round_name: schedForm.round_name, scheduled_at: new Date(schedForm.scheduled_at).toISOString(), venue: schedForm.venue, mode: schedForm.mode, interviewer: schedForm.interviewer });
      toast('Interview scheduled & student notified', 'success');
      setSched(null);
    } catch (e: any) { toast(e.message, 'error'); }
  };

  const exportCSV = () => {
    const csv = toCSV(rows.map(r => ({ student: r.student?.name, student_id: r.student?.student_id, dept: r.student?.department, job: r.job?.title, company: r.company?.name, status: r.status, applied: r.applied_at })), [
      { key: 'student', label: 'Student' }, { key: 'student_id', label: 'Student ID' }, { key: 'dept', label: 'Department' },
      { key: 'job', label: 'Job' }, { key: 'company', label: 'Company' }, { key: 'status', label: 'Status' }, { key: 'applied', label: 'Applied At' },
    ]);
    downloadCSV('applications.csv', csv);
    toast('Applications exported', 'success');
  };

  const stepIdx = (s: string) => s === 'rejected' ? -1 : STEPS.indexOf(s);

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">{isStudent ? 'My Applications' : 'Application Tracking'}</h1><p className="text-sm text-slate-500">{total} applications {isStudent ? 'submitted by you' : 'in pipeline'}</p></div>
        {!isStudent && <button onClick={exportCSV} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold hover:bg-slate-50 w-fit"><Download className="w-4 h-4" />Export CSV</button>}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search student, job, company…" className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-[#0b1f4b]" />{search && <button onClick={() => setSearch('')} className="absolute right-3 top-3 text-slate-400"><X className="w-4 h-4" /></button>}</div>
        <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Status</option><option value="applied">Applied</option><option value="shortlisted">Shortlisted</option><option value="selected">Selected</option><option value="rejected">Rejected</option><option value="withdrawn">Withdrawn</option></select>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading applications…" /></div> : rows.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title="No applications found" sub={isStudent ? 'Browse jobs and apply to get started' : 'Applications will appear here'} /></div> : (
        <div className="space-y-3">
          {rows.map(a => (
            <div key={a.id} className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 hover:shadow-md transition">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <span className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#0b1f4b] to-sky-600 text-white text-xs font-bold flex items-center justify-center shrink-0">{initials(a.student?.name || '?')}</span>
                  <div className="min-w-0">
                    <p className="font-bold text-sm sm:text-[15px] truncate">{!isStudent && `${a.student?.name} · `}{a.job?.title}</p>
                    <p className="text-xs text-slate-500 truncate">{a.company?.name} · {a.student?.department} · CGPA {a.student?.cgpa ?? '—'} · applied {formatDate(a.applied_at)}</p>
                  </div>
                </div>
                {/* pipeline */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {a.status === 'rejected' ? <Badge value="rejected" /> : a.status === 'withdrawn' ? <Badge value="withdrawn" /> : STEPS.map((s, i) => {
                    const idx = stepIdx(a.status);
                    const done = i <= idx;
                    return (
                      <div key={s} className="flex items-center gap-1.5">
                        <span className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-extrabold ${done ? (s === 'selected' ? 'bg-emerald-500 text-white' : 'bg-[#0b1f4b] text-white') : 'bg-slate-100 text-slate-400'}`}>{i + 1}</span>
                        <span className={`text-[11px] font-bold capitalize hidden sm:inline ${done ? 'text-slate-800' : 'text-slate-400'}`}>{s}</span>
                        {i < 2 && <span className={`w-5 h-0.5 rounded ${i < idx ? 'bg-[#0b1f4b]' : 'bg-slate-200'}`} />}
                      </div>
                    );
                  })}
                </div>
                <div className="flex flex-wrap gap-2 shrink-0">
                  {!isStudent ? (
                    <>
                      {a.status === 'applied' && <button onClick={() => setStatusOf(a, 'shortlisted')} className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-amber-100 text-amber-800 text-xs font-extrabold hover:bg-amber-200"><Star className="w-3.5 h-3.5" />Shortlist</button>}
                      {(a.status === 'applied' || a.status === 'shortlisted') && <button onClick={() => setStatusOf(a, 'selected')} className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-emerald-600 text-white text-xs font-extrabold hover:bg-emerald-700"><CheckCircle2 className="w-3.5 h-3.5" />Select</button>}
                      {(a.status === 'applied' || a.status === 'shortlisted') && <button onClick={() => setStatusOf(a, 'rejected')} className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-rose-50 text-rose-600 text-xs font-extrabold hover:bg-rose-100"><XCircle className="w-3.5 h-3.5" />Reject</button>}
                      {a.status === 'shortlisted' && <button onClick={() => openSched(a)} className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-sky-600 text-white text-xs font-extrabold hover:bg-sky-700"><CalendarPlus className="w-3.5 h-3.5" />Interview</button>}
                      <button onClick={() => setDel(a)} className="p-2 rounded-xl border text-rose-500 hover:bg-rose-50"><Trash2 className="w-4 h-4" /></button>
                    </>
                  ) : (
                    <>
                      <Badge value={a.status} />
                      {(a.status === 'applied' || a.status === 'shortlisted') && <button onClick={() => withdraw(a)} className="px-3 py-1.5 rounded-xl border text-xs font-bold text-slate-500 hover:bg-slate-50">Withdraw</button>}
                    </>
                  )}
                </div>
              </div>
              {a.cover_note && <p className="text-xs text-slate-500 mt-2.5 bg-slate-50 rounded-xl px-3 py-2">📝 {a.cover_note}</p>}
            </div>
          ))}
        </div>
      )}
      <Pagination page={page} total={total} limit={LIMIT} onPage={setPage} />

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Remove application?" message="Delete this application and its linked interviews?" />

      <Modal open={!!sched} onClose={() => setSched(null)} title={`Schedule Interview — ${sched?.student?.name}`}>
        <div className="space-y-4">
          <p className="text-sm text-slate-600 bg-sky-50 border border-sky-100 rounded-xl px-4 py-3">Scheduling for <b>{sched?.job?.title}</b> @ <b>{sched?.company?.name}</b>. The student will be notified instantly.</p>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Round" required><select value={schedForm.round_name} onChange={e => setSchedForm({ ...schedForm, round_name: e.target.value })} className={inputCls}><option>Aptitude Test</option><option>Technical Round 1</option><option>Technical Round 2</option><option>Group Discussion</option><option>HR Round</option><option>Final Interview</option></select></Field>
            <Field label="Date & time" required><input type="datetime-local" value={schedForm.scheduled_at} onChange={e => setSchedForm({ ...schedForm, scheduled_at: e.target.value })} className={inputCls} /></Field>
            <Field label="Mode"><select value={schedForm.mode} onChange={e => setSchedForm({ ...schedForm, mode: e.target.value })} className={inputCls}><option>Offline</option><option>Online</option><option>Hybrid</option></select></Field>
            <Field label="Venue / Link"><input value={schedForm.venue} onChange={e => setSchedForm({ ...schedForm, venue: e.target.value })} className={inputCls} placeholder="Seminar Hall 2 / meet link" /></Field>
            <div className="sm:col-span-2"><Field label="Interviewer"><input value={schedForm.interviewer} onChange={e => setSchedForm({ ...schedForm, interviewer: e.target.value })} className={inputCls} placeholder="Ms. Rao, TechNova" /></Field></div>
          </div>
          <div className="flex gap-3"><button onClick={() => setSched(null)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm">Cancel</button><button onClick={saveSched} className="flex-1 py-2.5 rounded-xl bg-sky-600 text-white font-bold text-sm hover:bg-sky-700">Schedule & Notify</button></div>
        </div>
      </Modal>
      <span className="hidden">{formatDateTime('')}</span>
    </div>
  );
}
