import { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Globe, MapPin, Briefcase, X } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Modal, ConfirmDialog, Field, inputCls, Empty, Spinner, Pagination } from '../components/UI';
import { INDUSTRIES } from '../lib/utils';

const empty = { name: '', industry: 'IT & Software', website: '', location: '', description: '', contact_email: '', contact_phone: '' };

export default function Companies() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [industry, setIndustry] = useState('');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...empty });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [del, setDel] = useState<any>(null);
  const [view, setView] = useState<any>(null);
  const canEdit = user?.role === 'admin' || user?.role === 'officer';
  const LIMIT = 12;

  const fetchRows = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) q.set('search', search);
      if (industry) q.set('industry', industry);
      const d = await api.get(`/api/companies?${q.toString()}`);
      setRows(d.data || []); setTotal(d.total || 0);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchRows(); }, [page, industry]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); fetchRows(); }, 450); return () => clearTimeout(t); }, [search]);

  const openView = async (r: any) => {
    try { const d = await api.get(`/api/companies?id=${r.id}`); setView(d); } catch (e: any) { toast(e.message, 'error'); }
  };
  const openAdd = () => { setEditing(null); setForm({ ...empty }); setErrors({}); setModal(true); };
  const openEdit = (r: any) => { setEditing(r); setForm({ name: r.name, industry: r.industry || 'IT & Software', website: r.website || '', location: r.location || '', description: r.description || '', contact_email: r.contact_email || '', contact_phone: r.contact_phone || '' }); setErrors({}); setModal(true); };

  const save = async () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = 'Company name required';
    if (form.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.contact_email)) e.contact_email = 'Invalid email';
    setErrors(e);
    if (Object.keys(e).length) return;
    try {
      if (editing) await api.put('/api/companies', { ...form, id: editing.id });
      else await api.post('/api/companies', form);
      toast(editing ? 'Company updated' : 'Company added', 'success');
      setModal(false); fetchRows();
    } catch (err: any) { toast(err.message, 'error'); }
  };
  const remove = async () => {
    try { await api.del(`/api/companies?id=${del.id}`); toast('Company deleted', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">Company Management</h1><p className="text-sm text-slate-500">{total} recruiting partners</p></div>
        {canEdit && <button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c] w-fit"><Plus className="w-4 h-4" />Add Company</button>}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search companies, industry, location…" className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-[#0b1f4b]" />{search && <button onClick={() => setSearch('')} className="absolute right-3 top-3 text-slate-400"><X className="w-4 h-4" /></button>}</div>
        <select value={industry} onChange={e => { setIndustry(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Industries</option>{INDUSTRIES.map(d => <option key={d}>{d}</option>)}</select>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading companies…" /></div> : rows.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title="No companies found" /></div> : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {rows.map(c => (
            <div key={c.id} className="bg-white rounded-3xl border border-slate-200 p-5 hover:shadow-lg hover:border-amber-300 transition cursor-pointer" onClick={() => openView(c)}>
              <div className="flex items-start gap-3.5">
                <div className="w-13 h-13 min-w-[52px] min-h-[52px] rounded-2xl bg-gradient-to-br from-[#0b1f4b] to-sky-700 text-amber-400 font-extrabold flex items-center justify-center">{c.name.slice(0, 2).toUpperCase()}</div>
                <div className="flex-1 min-w-0"><p className="font-extrabold text-slate-900 truncate">{c.name}</p><p className="text-xs text-slate-500 font-medium">{c.industry || '—'}</p></div>
                {c.open_jobs > 0 && <span className="text-[11px] font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full whitespace-nowrap">{c.open_jobs} open</span>}
              </div>
              <p className="text-xs text-slate-500 mt-3 line-clamp-2 min-h-[32px]">{c.description || 'No description yet.'}</p>
              <div className="flex items-center gap-3 mt-3 text-[11px] text-slate-500 font-medium">
                {c.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{c.location}</span>}
                {c.website && <span className="flex items-center gap-1 truncate"><Globe className="w-3 h-3" />{c.website.replace(/^https?:\/\//, '')}</span>}
              </div>
              {canEdit && (
                <div className="flex gap-2 mt-4 pt-4 border-t" onClick={e => e.stopPropagation()}>
                  <button onClick={() => openEdit(c)} className="flex-1 py-2 rounded-xl border text-xs font-bold hover:bg-sky-50 hover:border-sky-200 text-sky-700 flex items-center justify-center gap-1.5"><Pencil className="w-3.5 h-3.5" />Edit</button>
                  <button onClick={() => setDel(c)} className="flex-1 py-2 rounded-xl border text-xs font-bold hover:bg-rose-50 hover:border-rose-200 text-rose-600 flex items-center justify-center gap-1.5"><Trash2 className="w-3.5 h-3.5" />Delete</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      <Pagination page={page} total={total} limit={LIMIT} onPage={setPage} />

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Company' : 'Add Company'} wide>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Company name" required error={errors.name}><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className={inputCls} placeholder="TechNova Solutions" /></Field>
          <Field label="Industry"><select value={form.industry} onChange={e => setForm({ ...form, industry: e.target.value })} className={inputCls}>{INDUSTRIES.map(d => <option key={d}>{d}</option>)}</select></Field>
          <Field label="Website"><input value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} className={inputCls} placeholder="https://example.com" /></Field>
          <Field label="Location"><input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className={inputCls} placeholder="Bengaluru" /></Field>
          <Field label="Contact email" error={errors.contact_email}><input value={form.contact_email} onChange={e => setForm({ ...form, contact_email: e.target.value })} className={inputCls} placeholder="hr@example.com" /></Field>
          <Field label="Contact phone"><input value={form.contact_phone} onChange={e => setForm({ ...form, contact_phone: e.target.value })} className={inputCls} placeholder="+91 80 4000 0000" /></Field>
          <div className="sm:col-span-2"><Field label="Description"><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className={inputCls} rows={3} placeholder="About the company, work culture, hiring focus…" /></Field></div>
          <div className="sm:col-span-2 flex gap-3"><button onClick={() => setModal(false)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm hover:bg-slate-50">Cancel</button><button onClick={save} className="flex-1 py-2.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm">{editing ? 'Save changes' : 'Add company'}</button></div>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Delete company?" message={`Remove ${del?.name} with all its jobs, applications & interviews?`} />

      <Modal open={!!view} onClose={() => setView(null)} title={view?.name || 'Company'}>
        {view && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-sm text-slate-600 flex-wrap">
              <span className="px-3 py-1 rounded-full bg-slate-100 font-bold text-xs">{view.industry}</span>
              {view.location && <span className="flex items-center gap-1 text-xs font-medium"><MapPin className="w-3.5 h-3.5" />{view.location}</span>}
              {view.website && <a href={view.website} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs font-bold text-sky-600 hover:underline"><Globe className="w-3.5 h-3.5" />Website</a>}
            </div>
            <p className="text-sm text-slate-600">{view.description || 'No description provided.'}</p>
            <div>
              <p className="font-bold text-sm mb-2.5 flex items-center gap-1.5"><Briefcase className="w-4 h-4" />Job postings ({(view.jobs || []).length})</p>
              <div className="space-y-2">{(view.jobs || []).map((j: any) => <div key={j.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 text-sm"><span className="font-semibold">{j.title}</span><span className={`text-[11px] font-bold px-2.5 py-1 rounded-full capitalize ${j.status === 'open' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'}`}>{j.status}</span></div>)}
                {(!view.jobs || view.jobs.length === 0) && <p className="text-sm text-slate-400">No jobs posted yet</p>}</div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
