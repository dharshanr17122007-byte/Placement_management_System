import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap, Building2, Briefcase, TrendingUp, ArrowRight, CheckCircle2, Users, CalendarClock, FileCheck2, ShieldCheck, BarChart3, Bell } from 'lucide-react';
import { api } from '../lib/api';

export default function Home() {
  const [stats, setStats] = useState<any>(null);
  const [jobs, setJobs] = useState<any[]>([]);
  const [companies, setCompanies] = useState<any[]>([]);

  useEffect(() => {
    api.get('/api/reports').then(setStats).catch(() => {});
    api.get('/api/jobs?status=open&limit=6').then(d => setJobs(d.data || [])).catch(() => {});
    api.get('/api/companies?limit=8').then(d => setCompanies(d.data || [])).catch(() => {});
  }, []);

  const t = stats?.totals || {};

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="sticky top-0 z-30 bg-[#0b1f4b] text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center"><GraduationCap className="w-6 h-6 text-[#0b1f4b]" /></div>
            <div><p className="font-extrabold text-lg leading-tight">Placement Management System</p><p className="text-[11px] text-white/60">College Career & Placement Cell</p></div>
          </div>
          <div className="flex items-center gap-2.5">
            <Link to="/login" className="px-4 py-2 rounded-xl text-sm font-semibold text-white/85 hover:text-white hover:bg-white/10">Sign in</Link>
            <Link to="/register" className="px-4 py-2 rounded-xl text-sm font-bold bg-amber-400 text-[#0b1f4b] hover:bg-amber-300">Register</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#0b1f4b] via-[#12306e] to-[#1e4fa3] text-white">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, white 1px, transparent 1px), radial-gradient(circle at 80% 70%, white 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 grid lg:grid-cols-2 gap-12 items-center relative">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest bg-amber-400/15 text-amber-300 px-3 py-1.5 rounded-full ring-1 ring-amber-400/30">🎓 Academic Year 2025–26 · Placements Open</span>
            <h1 className="text-4xl sm:text-5xl xl:text-6xl font-extrabold leading-tight mt-5">Your gateway to <span className="text-amber-400">dream careers</span></h1>
            <p className="text-white/75 text-lg mt-5 max-w-xl">The college placement cell connects students with top recruiters — browse drives, apply in one click, track interviews, and get placed. Officers manage the entire pipeline from one dashboard.</p>
            <div className="flex flex-wrap gap-3 mt-8">
              <Link to="/register" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-amber-400 text-[#0b1f4b] font-bold hover:bg-amber-300 transition shadow-xl">Get Started <ArrowRight className="w-4 h-4" /></Link>
              <Link to="/login" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl border border-white/25 font-bold hover:bg-white/10 transition">Officer Login</Link>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-10 max-w-md">
              {[{ v: (t.students ?? '—'), l: 'Students' }, { v: (t.companies ?? '—'), l: 'Recruiters' }, { v: `${t.placementPct ?? '—'}%`, l: 'Placed' }].map((s, i) => (
                <div key={i} className="bg-white/10 rounded-2xl p-4 text-center backdrop-blur"><p className="text-2xl font-extrabold text-amber-300">{s.v}</p><p className="text-xs text-white/70 font-semibold mt-0.5">{s.l}</p></div>
              ))}
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6, delay: 0.15 }} className="hidden lg:block">
            <div className="bg-white rounded-3xl shadow-2xl p-6 text-slate-800">
              <div className="flex items-center justify-between mb-4"><p className="font-bold">🔥 Latest Drives</p><Link to="/login" className="text-xs font-bold text-sky-600">View all →</Link></div>
              <div className="space-y-3">
                {jobs.slice(0, 4).map(j => (
                  <div key={j.id} className="flex items-center gap-3 p-3 rounded-2xl border border-slate-100 hover:border-amber-300 hover:shadow transition">
                    <div className="w-11 h-11 rounded-xl bg-[#0b1f4b] text-amber-400 font-extrabold flex items-center justify-center text-sm">{(j.company?.name || 'C').slice(0, 2).toUpperCase()}</div>
                    <div className="flex-1 min-w-0"><p className="font-bold text-sm truncate">{j.title}</p><p className="text-xs text-slate-500 truncate">{j.company?.name} · {j.location || 'On-campus'}</p></div>
                    {j.package_lpa && <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full whitespace-nowrap">{j.package_lpa} LPA</span>}
                  </div>
                ))}
                {jobs.length === 0 && <p className="text-sm text-slate-500 text-center py-6">Loading latest drives…</p>}
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="bg-slate-50 rounded-2xl p-3.5"><p className="text-[11px] font-bold text-slate-500 uppercase">Open positions</p><p className="text-xl font-extrabold">{t.totalOpenings ?? '—'}</p></div>
                <div className="bg-slate-50 rounded-2xl p-3.5"><p className="text-[11px] font-bold text-slate-500 uppercase">Interviews soon</p><p className="text-xl font-extrabold">{t.upcomingInterviews ?? '—'}</p></div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Recruiters marquee */}
      <section className="py-10 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-center text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">Our recruiting partners</p>
          <div className="flex flex-wrap justify-center gap-3">
            {companies.map(c => <span key={c.id} className="px-5 py-2.5 bg-white rounded-full border border-slate-200 text-sm font-bold text-slate-700 shadow-sm">{c.name}</span>)}
            {companies.length === 0 && <p className="text-sm text-slate-400">Loading recruiters…</p>}
          </div>
        </div>
      </section>

      {/* Features by role */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto"><h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900">One portal, three powerful roles</h2><p className="text-slate-500 mt-3">Role-based access gives every stakeholder exactly the tools they need.</p></div>
          <div className="grid md:grid-cols-3 gap-6 mt-10">
            {[
              { icon: Users, color: 'bg-sky-100 text-sky-700', title: 'For Students', pts: ['One-click job applications with eligibility check', 'Resume upload & profile management', 'Interview schedule with venue & reminders', 'Real-time application status + notifications'] },
              { icon: Briefcase, color: 'bg-amber-100 text-amber-700', title: 'For Placement Officers', pts: ['Manage companies, jobs & student records', 'Shortlist, schedule interviews & track offers', 'Department-wise & company-wise reports', 'CSV exports for placement brochures'] },
              { icon: ShieldCheck, color: 'bg-violet-100 text-violet-700', title: 'For Admins', pts: ['Full control: users, officers & all data', 'Live dashboards: % placed, selections, trends', 'Secure role-based access & audit-ready data', 'Placement statistics for NAAC / NBA reports'] },
            ].map((f, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="bg-white rounded-3xl border border-slate-200 p-7 shadow-sm hover:shadow-xl transition">
                <div className={`w-12 h-12 rounded-2xl ${f.color} flex items-center justify-center`}><f.icon className="w-6 h-6" /></div>
                <h3 className="font-extrabold text-xl mt-4">{f.title}</h3>
                <ul className="mt-4 space-y-2.5">{f.pts.map((p, j) => <li key={j} className="flex items-start gap-2.5 text-sm text-slate-600"><CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />{p}</li>)}</ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 bg-[#0b1f4b] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center"><h2 className="text-3xl font-extrabold">From registration to offer letter</h2><p className="text-white/60 mt-2">The complete placement journey in 4 steps</p></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-10">
            {[
              { icon: Users, t: '1. Register & build profile', d: 'Students sign up, add skills, CGPA and upload resumes.' },
              { icon: FileCheck2, t: '2. Apply to drives', d: 'Browse eligible openings and apply in a single click.' },
              { icon: CalendarClock, t: '3. Attend interviews', d: 'Officers schedule rounds; students get notified instantly.' },
              { icon: TrendingUp, t: '4. Get placed', d: 'Selections update dashboards and placement % live.' },
            ].map((s, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition"><s.icon className="w-8 h-8 text-amber-400" /><p className="font-bold mt-3">{s.t}</p><p className="text-sm text-white/65 mt-1.5">{s.d}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats band */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { icon: Users, v: t.students ?? '—', l: 'Registered students' },
            { icon: Building2, v: t.companies ?? '—', l: 'Partner companies' },
            { icon: Briefcase, v: t.openJobs ?? '—', l: 'Open job postings' },
            { icon: BarChart3, v: `${t.placementPct ?? '—'}%`, l: 'Placement rate' },
          ].map((s, i) => (
            <div key={i} className="bg-slate-50 rounded-3xl p-6 text-center border border-slate-100"><s.icon className="w-7 h-7 mx-auto text-[#0b1f4b]" /><p className="text-3xl font-extrabold mt-2">{s.v}</p><p className="text-sm text-slate-500 font-medium">{s.l}</p></div>
          ))}
        </div>
      </section>

      {/* CTA + demo creds */}
      <section className="pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="bg-gradient-to-r from-amber-400 to-amber-500 rounded-3xl p-8 sm:p-12 text-[#0b1f4b] grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-extrabold">Try the portal with demo accounts</h2>
              <p className="mt-2 font-medium text-[#0b1f4b]/75">Explore every role instantly — no setup needed.</p>
              <div className="flex flex-wrap gap-3 mt-6">
                <Link to="/login" className="px-6 py-3 rounded-xl bg-[#0b1f4b] text-white font-bold hover:bg-[#16295c] transition">Sign in now</Link>
                <Link to="/register" className="px-6 py-3 rounded-xl bg-white/60 font-bold hover:bg-white transition">Create student account</Link>
              </div>
            </div>
            <div className="bg-[#0b1f4b] text-white rounded-2xl p-5 space-y-2.5 text-sm font-mono">
              <p className="font-sans font-bold text-amber-300 text-xs uppercase tracking-widest">Demo credentials</p>
              <div className="bg-white/5 rounded-xl px-4 py-2.5">👑 admin@college.edu <span className="text-white/50">/ admin123</span></div>
              <div className="bg-white/5 rounded-xl px-4 py-2.5">💼 officer@college.edu <span className="text-white/50">/ officer123</span></div>
              <div className="bg-white/5 rounded-xl px-4 py-2.5">🎓 aarav.sharma@student.edu <span className="text-white/50">/ student123</span></div>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-slate-950 text-white/60 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm">
          <p className="flex items-center gap-2"><Bell className="w-4 h-4" /> Placement Management System · College Career Cell</p>
          <p>Secure REST APIs · Role-based access · Real-time analytics</p>
        </div>
      </footer>
    </div>
  );
}
