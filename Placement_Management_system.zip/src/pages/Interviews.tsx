import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, MapPin, Video, CalendarClock, User } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Modal, ConfirmDialog, Field, inputCls, Empty, Spinner, Badge } from '../components/UI';
import { formatDateTime } from '../lib/utils';

const empty = { student_id: '', job_id: '', round_name: 'Technical Round 1', scheduled_at: '', venue: '', mode: 'Offline', interviewer: '', result: 'scheduled', notes: '' };

export default function Interviews() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('upcoming');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...empty });
  const [del, setDel] = useState<any>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);
  const [me, setMe] = useState<any>(null);
  const isStudent = user?.role === 'student';

  const fetchRows = async (sid?: number) => {
    setLoading(true);
    try {
      let url = '/api/interviews';
      if (isStudent) url += `?student_id=${sid || me?.id}`;
      const d = await api.get(url);
      setRows(d || []);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (!isStudent) {
      Promise.all([api.get('/api/students?limit=100'), api.get('/api/jobs?limit=100')])
        .then(([s, j]) => { setStudents(s.data || []); setJobs(j.data || []); }).catch(() => {});
    }
    if (isStudent && user) {
      api.get(`/api/students?user_id=${user.id}&limit=1`).then(s => {
        const m = (s.data || [])[0];
        setMe(m || null);
        if (m) fetchRows(m.id); else setLoading(false);
      }).catch(() => setLoading(false));
    } else fetchRows();
  }, [user?.id]);

  const shown = rows.filter(r => {
    const future = new Date(r.scheduled_at) >= new Date();
    if (filter === 'upcoming') return future && r.result === 'scheduled';
    if (filter === 'past') return !future || r.result !== 'scheduled';
    return true;
  });

  const openAdd = () => {
    setEditing(null);
    const d = new Date(); d.setDate(d.getDate() + 2); d.setHours(10, 0, 0, 0);
    setForm({ ...empty, scheduled_at: d.toISOString().slice(0, 16), student_id: students[0]?.id || '', job_id: jobs[0]?.id || '' });
    setModal(true);
  };
  const openEdit = (r: any) => {
    setEditing(r);
    setForm({ student_id: r.student_id, job_id: r.job_id, round_name: r.round_name, scheduled_at: new Date(r.scheduled_at).toISOString().slice(0, 16), venue: r.venue || '', mode: r.mode || 'Offline', interviewer: r.interviewer || '', result: r.result || 'scheduled', notes: r.notes || '' });
    setModal(true);
  };

  const save = async () => {
    if (!form.student_id) { toast('Select a student', 'error'); return; }
    if (!form.job_id) { toast('Select a job', 'error'); return; }
    if (!form.scheduled_at) { toast('Pick date & time', 'error'); return; }
    try {
      const payload = { ...form, student_id: Number(form.student_id), job_id: Number(form.job_id), scheduled_at: new Date(form.scheduled_at).toISOString() };
      if (editing) await api.put('/api/interviews', { ...payload, id: editing.id });
      else await api.post('/api/interviews', payload);
      toast(editing ? 'Interview updated' : 'Interview scheduled & student notified', 'success');
      setModal(false); fetchRows();
    } catch (e: any) { toast(e.message, 'error'); }
  };
  const remove = async () => {
    try { await api.del(`/api/interviews?id=${del.id}`); toast('Interview deleted', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };
  const markResult = async (r: any, result: string) => {
    try { await api.put('/api/interviews', { id: r.id, result }); toast(`Marked as ${result}`, 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  // group by date
  const groups: Record<string, any[]> = {};
  shown.forEach(r => {
    const k = new Date(r.scheduled_at).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
    if (!groups[k]) groups[k] = [];
    groups[k].push(r);
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">{isStudent ? 'My Interview Schedule' : 'Interview Schedule'}</h1><p className="text-sm text-slate-500">{shown.length} interviews {filter}</p></div>
        <div className="flex gap-2">
          <div className="flex bg-white border border-slate-200 rounded-xl p-1 text-sm font-bold">
            {['upcoming', 'past', 'all'].map(f => <button key={f} onClick={() => setFilter(f)} className={`px-4 py-1.5 rounded-lg capitalize ${filter === f ? 'bg-[#0b1f4b] text-white' : 'text-slate-500 hover:bg-slate-50'}`}>{f}</button>)}
          </div>
          {!isStudent && <button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c]"><Plus className="w-4 h-4" />Schedule</button>}
        </div>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading interviews…" /></div> : shown.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title={`No ${filter} interviews`} sub={isStudent ? 'Shortlisted applications lead to interviews' : 'Schedule interviews from Applications or here'} /></div> : (
        <div className="space-y-6">
          {Object.entries(groups).map(([date, list]) => (
            <div key={date}>
              <p className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2"><CalendarClock className="w-4 h-4" />{date}</p>
              <div className="grid md:grid-cols-2 gap-3">
                {list.map(iv => (
                  <div key={iv.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition relative overflow-hidden">
                    <div className={`absolute left-0 top-0 w-1 h-full ${iv.result === 'passed' ? 'bg-emerald-500' : iv.result === 'failed' ? 'bg-rose-500' : 'bg-sky-500'}`} />
                    <div className="flex items-start justify-between gap-3">
                      <div><p className="font-extrabold">{iv.round_name}</p><p className="text-xs text-slate-500 font-medium mt-0.5">{iv.job?.title} @ {iv.company?.name}</p></div>
                      <Badge value={iv.result} />
                    </div>
                    <div className="mt-3 space-y-1.5 text-xs text-slate-600 font-medium">
                      {!isStudent && <p className="flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-slate-400" />{iv.student?.name} · {iv.student?.student_id} · {iv.student?.department}</p>}
                      <p className="flex items-center gap-1.5"><CalendarClock className="w-3.5 h-3.5 text-slate-400" />{formatDateTime(iv.scheduled_at)}</p>
                      <p className="flex items-center gap-1.5">{iv.mode === 'Online' ? <Video className="w-3.5 h-3.5 text-slate-400" /> : <MapPin className="w-3.5 h-3.5 text-slate-400" />}{iv.venue || iv.mode} · {iv.mode}</p>
                      {iv.interviewer && <p className="text-slate-500">Panel: {iv.interviewer}</p>}
                    </div>
                    {!isStudent && (
                      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t">
                        {iv.result === 'scheduled' && <>
                          <button onClick={() => markResult(iv, 'passed')} className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-extrabold hover:bg-emerald-100">✓ Pass</button>
                          <button onClick={() => markResult(iv, 'failed')} className="px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 text-xs font-extrabold hover:bg-rose-100">✕ Fail</button>
                        </>}
                        <div className="flex-1" />
                        <button onClick={() => openEdit(iv)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-600"><Pencil className="w-4 h-4" /></button>
                        <button onClick={() => setDel(iv)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Interview' : 'Schedule Interview'} wide>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Student" required><select value={form.student_id} onChange={e => setForm({ ...form, student_id: e.target.value })} className={inputCls}><option value="">Select…</option>{students.map(s => <option key={s.id} value={s.id}>{s.name} ({s.student_id})</option>)}</select></Field>
          <Field label="Job" required><select value={form.job_id} onChange={e => setForm({ ...form, job_id: e.target.value })} className={inputCls}><option value="">Select…</option>{jobs.map(j => <option key={j.id} value={j.id}>{j.title} — {j.company?.name}</option>)}</select></Field>
          <Field label="Round" required><select value={form.round_name} onChange={e => setForm({ ...form, round_name: e.target.value })} className={inputCls}><option>Aptitude Test</option><option>Technical Round 1</option><option>Technical Round 2</option><option>Group Discussion</option><option>HR Round</option><option>Final Interview</option></select></Field>
          <Field label="Date & time" required><input type="datetime-local" value={form.scheduled_at} onChange={e => setForm({ ...form, scheduled_at: e.target.value })} className={inputCls} /></Field>
          <Field label="Mode"><select value={form.mode} onChange={e => setForm({ ...form, mode: e.target.value })} className={inputCls}><option>Offline</option><option>Online</option><option>Hybrid</option></select></Field>
          <Field label="Venue / Link"><input value={form.venue} onChange={e => setForm({ ...form, venue: e.target.value })} className={inputCls} placeholder="Seminar Hall 2" /></Field>
          <Field label="Interviewer"><input value={form.interviewer} onChange={e => setForm({ ...form, interviewer: e.target.value })} className={inputCls} placeholder="Panel details" /></Field>
          <Field label="Result"><select value={form.result} onChange={e => setForm({ ...form, result: e.target.value })} className={inputCls}><option value="scheduled">Scheduled</option><option value="passed">Passed</option><option value="failed">Failed</option></select></Field>
          <div className="sm:col-span-2"><Field label="Notes"><textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} className={inputCls} rows={2} placeholder="Topics, documents to carry…" /></Field></div>
          <div className="sm:col-span-2 flex gap-3"><button onClick={() => setModal(false)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm">Cancel</button><button onClick={save} className="flex-1 py-2.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm">{editing ? 'Save changes' : 'Schedule & Notify'}</button></div>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Delete interview?" message="Remove this scheduled interview?" />
    </div>
  );
}
