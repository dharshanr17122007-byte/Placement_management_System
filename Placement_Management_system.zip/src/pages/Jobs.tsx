import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Search, Pencil, Trash2, MapPin, IndianRupee, Users, CalendarDays, X, Building2 } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Modal, ConfirmDialog, Field, inputCls, Empty, Spinner, Pagination, Badge } from '../components/UI';
import { DEPARTMENTS, formatDate } from '../lib/utils';

const empty = { company_id: '', title: '', description: '', department: 'All', min_cgpa: '6', location: '', job_type: 'Full-time', package_lpa: '', openings: '1', deadline: '', status: 'open' };

export default function Jobs() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sp] = useSearchParams();
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(sp.get('search') || '');
  const [status, setStatus] = useState(user?.role === 'student' ? 'open' : '');
  const [jobType, setJobType] = useState('');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...empty });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [del, setDel] = useState<any>(null);
  const [view, setView] = useState<any>(null);
  const [companies, setCompanies] = useState<any[]>([]);
  const [myApps, setMyApps] = useState<Set<number>>(new Set());
  const [myStudent, setMyStudent] = useState<any>(null);
  const [applying, setApplying] = useState<number | null>(null);
  const canEdit = user?.role === 'admin' || user?.role === 'officer';
  const LIMIT = 12;

  const fetchRows = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) q.set('search', search);
      if (status) q.set('status', status);
      if (jobType) q.set('job_type', jobType);
      const d = await api.get(`/api/jobs?${q.toString()}`);
      setRows(d.data || []); setTotal(d.total || 0);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    api.get('/api/companies?limit=100').then(d => setCompanies(d.data || [])).catch(() => {});
    if (user?.role === 'student' && user) {
      api.get(`/api/students?user_id=${user.id}&limit=1`).then(async s => {
        const me = (s.data || [])[0];
        setMyStudent(me || null);
        if (me) {
          const a = await api.get(`/api/applications?student_id=${me.id}&limit=200`);
          setMyApps(new Set((a.data || []).map((x: any) => x.job_id)));
        }
      }).catch(() => {});
    }
  }, [user?.id]);

  useEffect(() => { fetchRows(); }, [page, status, jobType]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); fetchRows(); }, 450); return () => clearTimeout(t); }, [search]);
  useEffect(() => { const s = sp.get('search'); if (s) setSearch(s); }, []);

  const openView = async (r: any) => {
    try { const d = await api.get(`/api/jobs?id=${r.id}`); setView(d); } catch (e: any) { toast(e.message, 'error'); }
  };
  const openAdd = () => { setEditing(null); setForm({ ...empty, company_id: companies[0]?.id || '' }); setErrors({}); setModal(true); };
  const openEdit = (r: any) => {
    setEditing(r);
    setForm({ company_id: r.company_id, title: r.title, description: r.description || '', department: r.department || 'All', min_cgpa: String(r.min_cgpa ?? 0), location: r.location || '', job_type: r.job_type || 'Full-time', package_lpa: r.package_lpa ?? '', openings: String(r.openings || 1), deadline: r.deadline ? String(r.deadline).slice(0, 10) : '', status: r.status || 'open' });
    setErrors({}); setModal(true);
  };

  const save = async () => {
    const e: Record<string, string> = {};
    if (!form.company_id) e.company_id = 'Select company';
    if (!form.title?.trim()) e.title = 'Title required';
    if (form.min_cgpa !== '' && (isNaN(Number(form.min_cgpa)) || Number(form.min_cgpa) < 0 || Number(form.min_cgpa) > 10)) e.min_cgpa = 'CGPA 0–10';
    if (!form.openings || Number(form.openings) < 1) e.openings = 'Min 1';
    setErrors(e);
    if (Object.keys(e).length) return;
    try {
      const payload = { ...form, company_id: Number(form.company_id), min_cgpa: form.min_cgpa === '' ? 0 : Number(form.min_cgpa), package_lpa: form.package_lpa === '' ? null : Number(form.package_lpa), openings: Number(form.openings), deadline: form.deadline || null, created_by: user?.id };
      if (editing) await api.put('/api/jobs', { ...payload, id: editing.id });
      else await api.post('/api/jobs', payload);
      toast(editing ? 'Job updated' : 'Job posted', 'success');
      setModal(false); fetchRows();
    } catch (err: any) { toast(err.message, 'error'); }
  };
  const remove = async () => {
    try { await api.del(`/api/jobs?id=${del.id}`); toast('Job deleted', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  const apply = async (job: any) => {
    if (!myStudent) { toast('Student profile not found. Contact placement cell.', 'error'); return; }
    setApplying(job.id);
    try {
      await api.post('/api/applications', { job_id: job.id, student_id: myStudent.id });
      setMyApps(prev => new Set(prev).add(job.id));
      toast(`Applied for ${job.title}!`, 'success');
      setView(null); fetchRows();
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setApplying(null); }
  };

  const eligible = (j: any) => {
    if (!myStudent) return true;
    if (j.min_cgpa && myStudent.cgpa !== null && Number(myStudent.cgpa) < Number(j.min_cgpa)) return false;
    if (j.department && j.department !== 'All') {
      const allowed = String(j.department).split(',').map(x => x.trim());
      if (!allowed.includes(myStudent.department)) return false;
    }
    return true;
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">{user?.role === 'student' ? 'Browse Job Openings' : 'Job Management'}</h1><p className="text-sm text-slate-500">{total} postings {user?.role === 'student' ? 'available' : 'in system'}</p></div>
        {canEdit && <button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c] w-fit"><Plus className="w-4 h-4" />Post Job</button>}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search jobs, location, skills…" className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-[#0b1f4b]" />{search && <button onClick={() => setSearch('')} className="absolute right-3 top-3 text-slate-400"><X className="w-4 h-4" /></button>}</div>
        {canEdit && <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Status</option><option value="open">Open</option><option value="closed">Closed</option></select>}
        <select value={jobType} onChange={e => { setJobType(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Types</option><option>Full-time</option><option>Internship</option><option>Part-time</option><option>Contract</option></select>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading jobs…" /></div> : rows.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title="No jobs found" sub="Try different filters" /></div> : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {rows.map(j => {
            const applied = myApps.has(j.id);
            const ok = eligible(j);
            return (
              <div key={j.id} className="bg-white rounded-3xl border border-slate-200 p-5 hover:shadow-lg hover:border-amber-300 transition flex flex-col cursor-pointer" onClick={() => openView(j)}>
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0b1f4b] to-sky-700 text-amber-400 font-extrabold flex items-center justify-center text-sm shrink-0">{(j.company?.name || 'C').slice(0, 2).toUpperCase()}</div>
                  <div className="flex-1 min-w-0"><p className="font-extrabold text-slate-900 leading-snug">{j.title}</p><p className="text-xs text-slate-500 font-medium flex items-center gap-1 mt-0.5"><Building2 className="w-3 h-3" />{j.company?.name || '—'}</p></div>
                  <Badge value={j.status} />
                </div>
                <div className="flex flex-wrap gap-x-3 gap-y-1.5 mt-3 text-[11px] text-slate-500 font-semibold">
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{j.location || 'On-campus'}</span>
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{j.job_type}</span>
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">{j.department} · CGPA ≥ {j.min_cgpa}</span>
                </div>
                <div className="flex items-center gap-3 mt-3 text-xs">
                  {j.package_lpa ? <span className="flex items-center gap-0.5 font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full"><IndianRupee className="w-3 h-3" />{j.package_lpa} LPA</span> : <span className="text-slate-400 font-medium">Package on discussion</span>}
                  <span className="flex items-center gap-1 text-slate-500 font-semibold"><Users className="w-3.5 h-3.5" />{j.openings} openings</span>
                  {j.deadline && <span className="flex items-center gap-1 text-slate-500 ml-auto"><CalendarDays className="w-3.5 h-3.5" />{formatDate(j.deadline)}</span>}
                </div>
                <div className="flex items-center gap-2 mt-4 pt-4 border-t mt-auto" onClick={e => e.stopPropagation()}>
                  <span className="text-[11px] text-slate-400 font-semibold">{j.applications_count} applicants</span>
                  <div className="flex-1" />
                  {canEdit ? (
                    <><button onClick={() => openEdit(j)} className="px-3.5 py-2 rounded-xl border text-xs font-bold hover:bg-sky-50 text-sky-700 flex items-center gap-1"><Pencil className="w-3.5 h-3.5" />Edit</button><button onClick={() => setDel(j)} className="px-3.5 py-2 rounded-xl border text-xs font-bold hover:bg-rose-50 text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button></>
                  ) : applied ? (
                    <span className="px-4 py-2 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-extrabold">✓ Applied</span>
                  ) : (
                    <button disabled={!ok || applying === j.id} onClick={() => apply(j)} title={!ok ? 'Not eligible (CGPA/department)' : 'Apply now'} className={`px-4 py-2 rounded-xl text-xs font-extrabold ${ok ? 'bg-[#0b1f4b] text-white hover:bg-[#16295c]' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}>{applying === j.id ? 'Applying…' : ok ? 'Apply Now' : 'Not Eligible'}</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      <Pagination page={page} total={total} limit={LIMIT} onPage={setPage} />

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Job' : 'Post New Job'} wide>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Company" required error={errors.company_id}><select value={form.company_id} onChange={e => setForm({ ...form, company_id: e.target.value })} className={inputCls}><option value="">Select company…</option>{companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
          <Field label="Job title" required error={errors.title}><input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className={inputCls} placeholder="Software Engineer" /></Field>
          <div className="sm:col-span-2"><Field label="Description"><textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className={inputCls} rows={4} placeholder="Role overview, responsibilities, required skills, selection process…" /></Field></div>
          <Field label="Eligible department"><select value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className={inputCls}><option value="All">All Departments</option>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}<option value="CSE,IT,AIDS">CSE, IT, AIDS</option><option value="ECE,EEE">ECE, EEE</option><option value="ME,CE">ME, CE</option></select></Field>
          <Field label="Min CGPA" error={errors.min_cgpa}><input value={form.min_cgpa} onChange={e => setForm({ ...form, min_cgpa: e.target.value })} className={inputCls} inputMode="decimal" placeholder="6.0" /></Field>
          <Field label="Location"><input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className={inputCls} placeholder="Bengaluru / Remote" /></Field>
          <Field label="Job type"><select value={form.job_type} onChange={e => setForm({ ...form, job_type: e.target.value })} className={inputCls}><option>Full-time</option><option>Internship</option><option>Part-time</option><option>Contract</option></select></Field>
          <Field label="Package (LPA)"><input value={form.package_lpa} onChange={e => setForm({ ...form, package_lpa: e.target.value })} className={inputCls} inputMode="decimal" placeholder="8.5" /></Field>
          <Field label="Openings" error={errors.openings}><input type="number" min={1} value={form.openings} onChange={e => setForm({ ...form, openings: e.target.value })} className={inputCls} /></Field>
          <Field label="Deadline"><input type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} className={inputCls} /></Field>
          <Field label="Status"><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className={inputCls}><option value="open">Open</option><option value="closed">Closed</option></select></Field>
          <div className="sm:col-span-2 flex gap-3"><button onClick={() => setModal(false)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm hover:bg-slate-50">Cancel</button><button onClick={save} className="flex-1 py-2.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm">{editing ? 'Save changes' : 'Publish job'}</button></div>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Delete job?" message={`Remove "${del?.title}" and all its applications?`} />

      <Modal open={!!view} onClose={() => setView(null)} title={view?.title || 'Job Details'} wide>
        {view && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-13 min-w-[52px] min-h-[52px] rounded-2xl bg-gradient-to-br from-[#0b1f4b] to-sky-700 text-amber-400 font-extrabold flex items-center justify-center">{(view.company?.name || 'C').slice(0, 2).toUpperCase()}</div>
              <div><p className="font-extrabold text-lg leading-tight">{view.title}</p><p className="text-sm text-slate-500">{view.company?.name} · {view.location || 'On-campus'}</p></div>
              <span className="ml-auto"><Badge value={view.status} /></span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
              {[[view.package_lpa ? `${view.package_lpa} LPA` : '—', 'Package'], [`${view.openings}`, 'Openings'], [`CGPA ≥ ${view.min_cgpa}`, 'Eligibility'], [view.applications_count ?? 0, 'Applicants']].map(([v, l], i) => (
                <div key={i} className="bg-slate-50 rounded-xl p-3"><p className="font-extrabold">{v}</p><p className="text-[11px] text-slate-500 font-semibold">{l}</p></div>
              ))}
            </div>
            <div><p className="text-xs font-bold uppercase text-slate-400 mb-1.5">Eligible departments</p><p className="text-sm font-semibold">{view.department}</p>{view.deadline && <p className="text-xs text-rose-600 font-bold mt-1">⏰ Apply by {formatDate(view.deadline)}</p>}</div>
            <div><p className="text-xs font-bold uppercase text-slate-400 mb-1.5">Job description</p><p className="text-sm text-slate-600 whitespace-pre-line">{view.description || 'No description provided.'}</p></div>
            {!canEdit && (
              myApps.has(view.id) ? <div className="py-3 rounded-xl bg-emerald-50 text-emerald-700 text-sm font-extrabold text-center">✓ Application submitted</div>
              : <button disabled={!eligible(view) || applying === view.id} onClick={() => apply(view)} className={`w-full py-3 rounded-xl text-sm font-extrabold ${eligible(view) ? 'bg-[#0b1f4b] text-white hover:bg-[#16295c]' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}>{applying === view.id ? 'Submitting…' : eligible(view) ? 'Apply for this job' : 'Not eligible for this job'}</button>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
