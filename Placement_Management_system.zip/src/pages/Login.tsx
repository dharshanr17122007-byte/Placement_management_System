import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { GraduationCap, Mail, Lock, Eye, EyeOff, LogIn } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { isEmail } from '../lib/utils';

const QUICK = [
  { label: 'Admin', email: 'admin@college.edu', pass: 'admin123' },
  { label: 'Officer', email: 'officer@college.edu', pass: 'officer123' },
  { label: 'Student', email: 'aarav.sharma@student.edu', pass: 'student123' },
];

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();
  const nav = useNavigate();
  const loc = useLocation() as any;

  const submit = async (e?: React.FormEvent, em?: string, pw?: string) => {
    e?.preventDefault();
    const E = em ?? email, P = pw ?? password;
    const errs: Record<string, string> = {};
    if (!E || !isEmail(E)) errs.email = 'Enter a valid email address';
    if (!P) errs.password = 'Password is required';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      const u = await login(E.trim(), P);
      toast(`Welcome back, ${u.name}!`, 'success');
      const from = loc.state?.from;
      if (from && from !== '/login') nav(from, { replace: true });
      else nav(u.role === 'admin' ? '/admin' : u.role === 'officer' ? '/officer' : '/student', { replace: true });
    } catch (err: any) {
      toast(err.message || 'Login failed', 'error');
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between bg-gradient-to-br from-[#0b1f4b] via-[#12306e] to-sky-800 text-white p-12">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-400 flex items-center justify-center"><GraduationCap className="w-7 h-7 text-[#0b1f4b]" /></div>
          <div><p className="font-extrabold text-lg">Placement Management System</p><p className="text-xs text-white/60">College Career & Placement Cell</p></div>
        </Link>
        <div>
          <h1 className="text-4xl font-extrabold leading-tight">Sign in to your<br />placement journey</h1>
          <p className="text-white/70 mt-4 max-w-md">Students track applications and interviews. Officers run drives end-to-end. Admins see everything, live.</p>
          <div className="flex gap-6 mt-8 text-center">
            {[['120+', 'Hiring partners'], ['92%', 'Placement rate'], ['4.8★', 'Student rating']].map(([v, l], i) => (
              <div key={i}><p className="text-2xl font-extrabold text-amber-300">{v}</p><p className="text-xs text-white/60">{l}</p></div>
            ))}
          </div>
        </div>
        <p className="text-xs text-white/40">Protected by role-based access control · Secure token auth</p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-10 bg-slate-50">
        <div className="w-full max-w-md">
          <Link to="/" className="lg:hidden flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl bg-[#0b1f4b] flex items-center justify-center"><GraduationCap className="w-5 h-5 text-amber-400" /></div>
            <span className="font-extrabold">Placement Portal</span>
          </Link>
          <h2 className="text-3xl font-extrabold text-slate-900">Welcome back</h2>
          <p className="text-sm text-slate-500 mt-1.5">Sign in to continue to your dashboard</p>

          <form onSubmit={(e) => submit(e)} className="mt-7 space-y-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <div>
              <label className="text-xs font-bold uppercase tracking-wide text-slate-600">Email</label>
              <div className="relative mt-1.5"><Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input value={email} onChange={e => setEmail(e.target.value)} placeholder="you@college.edu" className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-[#0b1f4b]/20 focus:border-[#0b1f4b]" />
              </div>
              {errors.email && <p className="text-xs text-rose-600 mt-1">{errors.email}</p>}
            </div>
            <div>
              <label className="text-xs font-bold uppercase tracking-wide text-slate-600">Password</label>
              <div className="relative mt-1.5"><Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input type={show ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="w-full pl-10 pr-11 py-3 rounded-xl border border-slate-200 text-sm outline-none focus:ring-2 focus:ring-[#0b1f4b]/20 focus:border-[#0b1f4b]" />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-3 text-slate-400">{show ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}</button>
              </div>
              {errors.password && <p className="text-xs text-rose-600 mt-1">{errors.password}</p>}
            </div>
            <button disabled={busy} className="w-full py-3 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm hover:bg-[#16295c] transition disabled:opacity-60 flex items-center justify-center gap-2">
              {busy ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : <LogIn className="w-4 h-4" />} {busy ? 'Signing in…' : 'Sign in'}
            </button>
            <p className="text-sm text-center text-slate-500">New student? <Link to="/register" className="font-bold text-[#0b1f4b] hover:underline">Create an account</Link></p>
          </form>

          <div className="mt-5 bg-white rounded-3xl border border-slate-200 p-5">
            <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">One-click demo login</p>
            <div className="grid grid-cols-3 gap-2">
              {QUICK.map(q => (
                <button key={q.label} disabled={busy} onClick={() => submit(undefined, q.email, q.pass)} className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-bold hover:border-amber-400 hover:bg-amber-50 transition disabled:opacity-50">{q.label}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
