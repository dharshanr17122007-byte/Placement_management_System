import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, Briefcase, FileCheck2, CalendarClock, Plus, ArrowRight, Building2, Clock } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import StatCard from '../components/StatCard';
import { Spinner, Badge } from '../components/UI';
import { BarChart } from '../components/Charts';
import { formatDateTime } from '../lib/utils';

export default function OfficerDashboard() {
  const { user } = useAuth();
  const [rep, setRep] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState<any[]>([]);
  const [interviews, setInterviews] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([
      api.get('/api/reports'),
      api.get('/api/applications?status=applied&limit=8'),
      api.get('/api/interviews?upcoming=true'),
      api.get('/api/jobs?status=open&limit=5'),
    ]).then(([r, a, iv, j]) => { setRep(r); setPending(a.data || []); setInterviews((iv || []).slice(0, 6)); setJobs(j.data || []); })
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner label="Loading officer dashboard…" />;
  const t = rep?.totals || {};

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 rounded-3xl p-6 sm:p-8 text-[#0b1f4b] flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest opacity-70">Placement Officer Console</p>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">Namaste, {user?.name?.split(' ')[0]} 🙏</h1>
          <p className="text-sm mt-1.5 opacity-75">{pending.length} applications awaiting review · {interviews.length} interviews upcoming</p>
        </div>
        <div className="flex flex-wrap gap-2.5">
          <Link to="/jobs" className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c]"><Plus className="w-4 h-4" />Post Job</Link>
          <Link to="/companies" className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/70 text-sm font-bold hover:bg-white"><Building2 className="w-4 h-4" />Add Company</Link>
          <Link to="/interviews" className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/70 text-sm font-bold hover:bg-white"><CalendarClock className="w-4 h-4" />Schedule</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Eligible Students" value={t.eligible ?? 0} icon={Users} tone="bg-sky-500" sub={`of ${t.students ?? 0} registered`} />
        <StatCard label="Open Drives" value={t.openJobs ?? 0} icon={Briefcase} tone="bg-amber-500" sub={`${t.totalOpenings ?? 0} positions`} />
        <StatCard label="Pending Review" value={pending.length} icon={FileCheck2} tone="bg-rose-500" sub="applications to shortlist" />
        <StatCard label="Upcoming Interviews" value={t.upcomingInterviews ?? 0} icon={CalendarClock} tone="bg-emerald-500" sub="scheduled rounds" />
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 lg:col-span-3">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800 flex items-center gap-2"><Clock className="w-4 h-4 text-rose-500" />Needs Your Review</p><Link to="/applications?status=applied" className="text-xs font-bold text-sky-600 hover:underline flex items-center gap-1">Review all <ArrowRight className="w-3.5 h-3.5" /></Link></div>
          <div className="space-y-2.5">
            {pending.map(a => (
              <Link key={a.id} to={`/applications?status=applied`} className="flex items-center gap-3 p-3 rounded-2xl bg-slate-50 hover:bg-amber-50 hover:ring-1 hover:ring-amber-200 transition">
                <div className="w-10 h-10 rounded-xl bg-white border text-xs font-bold flex items-center justify-center shrink-0 text-[#0b1f4b]">{(a.student?.name || '?').split(' ').map((w: string) => w[0]).slice(0, 2).join('')}</div>
                <div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{a.student?.name} <span className="text-slate-400 font-medium">· CGPA {a.student?.cgpa ?? '—'}</span></p><p className="text-xs text-slate-500 truncate">{a.job?.title} @ {a.company?.name} · {a.student?.department}</p></div>
                <Badge value={a.status} />
              </Link>
            ))}
            {pending.length === 0 && <p className="text-sm text-slate-400 text-center py-6">All caught up! No pending applications 🎉</p>}
          </div>
        </div>
        <div className="bg-white rounded-3xl border border-slate-200 p-6 lg:col-span-2">
          <p className="font-bold text-slate-800 mb-4">Monthly Trend</p>
          <BarChart data={(rep?.monthly || []).map((m: any) => ({ label: m.month, value: m.applications, value2: m.selected }))} height={200} />
          <div className="flex gap-4 mt-3 text-xs text-slate-500"><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#0b1f4b]" />Applications</span><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-500" />Selected</span></div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">Active Job Postings</p><Link to="/jobs" className="text-xs font-bold text-sky-600 hover:underline">Manage →</Link></div>
          <div className="space-y-2.5">
            {jobs.map(j => (
              <div key={j.id} className="flex items-center gap-3 p-3 rounded-2xl border border-slate-100">
                <div className="w-10 h-10 rounded-xl bg-[#0b1f4b] text-amber-400 text-xs font-extrabold flex items-center justify-center shrink-0">{(j.company?.name || 'C').slice(0, 2).toUpperCase()}</div>
                <div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{j.title}</p><p className="text-xs text-slate-500">{j.company?.name} · {j.applications_count} applicants</p></div>
                {j.package_lpa && <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">{j.package_lpa} LPA</span>}
              </div>
            ))}
            {jobs.length === 0 && <p className="text-sm text-slate-400 text-center py-4">No open jobs — post one to start a drive</p>}
          </div>
        </div>
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">Interview Calendar</p><Link to="/interviews" className="text-xs font-bold text-sky-600 hover:underline">Full schedule →</Link></div>
          <div className="space-y-2.5">
            {interviews.map(iv => (
              <div key={iv.id} className="flex items-center gap-3 p-3 rounded-2xl bg-sky-50/60 border border-sky-100">
                <div className="flex-1 min-w-0"><p className="text-sm font-bold truncate">{iv.round_name} — {iv.student?.name}</p><p className="text-xs text-slate-500 truncate">{iv.job?.title} · {formatDateTime(iv.scheduled_at)} · {iv.venue || iv.mode}</p></div>
                <Badge value={iv.result} />
              </div>
            ))}
            {interviews.length === 0 && <p className="text-sm text-slate-400 text-center py-4">Nothing scheduled yet</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
