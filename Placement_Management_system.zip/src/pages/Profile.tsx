import { useEffect, useState } from 'react';
import { Upload, FileText, Save, CheckCircle2 } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Field, inputCls, Spinner, Badge } from '../components/UI';
import { isPhone, isCGPA, DEPARTMENTS, YEARS, initials } from '../lib/utils';

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [student, setStudent] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const isStudent = user?.role === 'student';

  useEffect(() => {
    if (!user) return;
    if (!isStudent) { setForm({ name: user.name, phone: user.phone || '' }); setLoading(false); return; }
    api.get(`/api/students?user_id=${user.id}&limit=1`).then(s => {
      const m = (s.data || [])[0];
      setStudent(m || null);
      if (m) setForm({ name: m.name, phone: m.phone || '', department: m.department, year: m.year, cgpa: m.cgpa ?? '', skills: m.skills || '' });
    }).catch(() => {}).finally(() => setLoading(false));
  }, [user?.id]);

  const save = async () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = 'Name required';
    if (form.phone && !isPhone(form.phone)) e.phone = 'Invalid phone';
    if (isStudent && !isCGPA(form.cgpa)) e.cgpa = 'CGPA 0–10';
    setErrors(e);
    if (Object.keys(e).length) return;
    setSaving(true);
    try {
      if (isStudent && student) {
        const updated = await api.put('/api/students', { id: student.id, name: form.name.trim(), phone: form.phone, department: form.department, year: form.year, cgpa: form.cgpa === '' ? null : Number(form.cgpa), skills: form.skills });
        setStudent(updated);
      } else if (user) {
        await api.put('/api/users', { id: user.id, name: form.name.trim(), phone: form.phone });
      }
      toast('Profile saved', 'success');
    } catch (err: any) { toast(err.message, 'error'); }
    finally { setSaving(false); }
  };

  const onFile = async (file: File) => {
    if (!file) return;
    const ok = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!ok.includes(file.type) && !/\.(pdf|doc|docx)$/i.test(file.name)) { toast('Only PDF / DOC / DOCX allowed', 'error'); return; }
    if (file.size > 8 * 1024 * 1024) { toast('Max 8MB allowed', 'error'); return; }
    setUploading(true);
    try {
      const b64 = await new Promise<string>((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result).split(',')[1]);
        r.onerror = rej;
        r.readAsDataURL(file);
      });
      const up = await api.post('/api/upload', { fileName: file.name, fileBase64: b64, contentType: file.type });
      const updated = await api.put('/api/students', { id: student.id, resume_url: up.url });
      setStudent(updated);
      toast('Resume uploaded successfully', 'success');
    } catch (err: any) { toast(err.message || 'Upload failed', 'error'); }
    finally { setUploading(false); }
  };

  if (loading) return <Spinner label="Loading profile…" />;

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div><h1 className="text-2xl font-extrabold text-slate-900">My Profile</h1><p className="text-sm text-slate-500">Keep your details up to date</p></div>

      <div className="bg-gradient-to-r from-[#0b1f4b] to-sky-700 rounded-3xl p-6 text-white flex items-center gap-4">
        <span className="w-16 h-16 rounded-2xl bg-amber-400 text-[#0b1f4b] font-extrabold flex items-center justify-center text-xl">{initials(user?.name || '')}</span>
        <div><p className="font-extrabold text-lg">{user?.name}</p><p className="text-sm text-white/70">{user?.email}</p><span className="inline-block mt-1.5 text-[11px] font-extrabold uppercase tracking-wider bg-white/15 px-2.5 py-1 rounded-full capitalize">{user?.role}</span></div>
        {student && <span className="ml-auto hidden sm:block"><Badge value={student.status} /></span>}
      </div>

      {isStudent && student && (
        <div className="bg-white rounded-3xl border p-6">
          <p className="font-bold mb-3 flex items-center gap-2"><FileText className="w-4 h-4" />Resume</p>
          {student.resume_url ? (
            <div className="flex items-center gap-3 bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
              <div className="flex-1 min-w-0"><p className="text-sm font-bold text-emerald-900">Resume on file</p><a href={student.resume_url} target="_blank" rel="noreferrer" className="text-xs font-bold text-sky-600 hover:underline break-all">View / download current resume</a></div>
              <label className="px-4 py-2 rounded-xl bg-white border text-xs font-bold hover:bg-slate-50 cursor-pointer whitespace-nowrap">{uploading ? 'Uploading…' : 'Replace'}<input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={e => e.target.files?.[0] && onFile(e.target.files[0])} /></label>
            </div>
          ) : (
            <label className="block border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center cursor-pointer hover:border-amber-400 hover:bg-amber-50/50 transition">
              <Upload className="w-8 h-8 mx-auto text-slate-400" />
              <p className="font-bold text-sm mt-2">{uploading ? 'Uploading…' : 'Click to upload resume'}</p>
              <p className="text-xs text-slate-400 mt-1">PDF, DOC or DOCX · max 8MB</p>
              <input type="file" className="hidden" accept=".pdf,.doc,.docx" onChange={e => e.target.files?.[0] && onFile(e.target.files[0])} />
            </label>
          )}
        </div>
      )}

      <div className="bg-white rounded-3xl border p-6">
        <p className="font-bold mb-4">{isStudent ? 'Student Details' : 'Account Details'}</p>
        {isStudent && student && (
          <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
            <div className="bg-slate-50 rounded-xl p-3"><p className="text-[11px] font-bold uppercase text-slate-400">Student ID</p><p className="font-mono font-bold">{student.student_id}</p></div>
            <div className="bg-slate-50 rounded-xl p-3"><p className="text-[11px] font-bold uppercase text-slate-400">Email (login)</p><p className="font-semibold truncate">{student.email}</p></div>
          </div>
        )}
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Full name" required error={errors.name}><input value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
          <Field label="Phone" error={errors.phone}><input value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} className={inputCls} placeholder="+91…" /></Field>
          {isStudent && <>
            <Field label="Department"><select value={form.department || 'CSE'} onChange={e => setForm({ ...form, department: e.target.value })} className={inputCls}>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}</select></Field>
            <Field label="Year"><select value={form.year || '3rd'} onChange={e => setForm({ ...form, year: e.target.value })} className={inputCls}>{YEARS.map(y => <option key={y}>{y}</option>)}</select></Field>
            <Field label="CGPA (0–10)" error={errors.cgpa}><input value={form.cgpa ?? ''} onChange={e => setForm({ ...form, cgpa: e.target.value })} className={inputCls} inputMode="decimal" /></Field>
            <Field label="Skills (comma separated)"><input value={form.skills || ''} onChange={e => setForm({ ...form, skills: e.target.value })} className={inputCls} placeholder="Java, React, SQL" /></Field>
          </>}
        </div>
        <button onClick={save} disabled={saving} className="mt-5 w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c] disabled:opacity-60">
          {saving ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : <Save className="w-4 h-4" />} {saving ? 'Saving…' : 'Save changes'}
        </button>
      </div>
    </div>
  );
}
