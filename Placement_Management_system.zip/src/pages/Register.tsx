import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { GraduationCap, UserPlus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Field, inputCls } from '../components/UI';
import { isEmail, isPhone, isCGPA, DEPARTMENTS, YEARS } from '../lib/utils';

export default function Register() {
  const [f, setF] = useState({ name: '', email: '', password: '', confirm: '', phone: '', department: 'CSE', year: '3rd', cgpa: '', skills: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const { register } = useAuth();
  const { toast } = useToast();
  const nav = useNavigate();
  const upd = (k: string, v: string) => setF(p => ({ ...p, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!f.name.trim()) errs.name = 'Full name is required';
    if (!isEmail(f.email)) errs.email = 'Enter a valid email';
    if (f.password.length < 6) errs.password = 'Minimum 6 characters';
    if (f.confirm !== f.password) errs.confirm = 'Passwords do not match';
    if (f.phone && !isPhone(f.phone)) errs.phone = 'Invalid phone number';
    if (!isCGPA(f.cgpa)) errs.cgpa = 'CGPA must be 0–10';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setBusy(true);
    try {
      await register({ name: f.name.trim(), email: f.email.trim(), password: f.password, phone: f.phone, department: f.department, year: f.year, cgpa: f.cgpa, skills: f.skills });
      toast('Account created! Welcome aboard', 'success');
      nav('/student', { replace: true });
    } catch (err: any) { toast(err.message || 'Registration failed', 'error'); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <Link to="/" className="flex items-center gap-2 mb-6 justify-center">
          <div className="w-10 h-10 rounded-xl bg-[#0b1f4b] flex items-center justify-center"><GraduationCap className="w-6 h-6 text-amber-400" /></div>
          <span className="font-extrabold text-lg">Placement Portal</span>
        </Link>
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-7 sm:p-9">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 text-center">Student Registration</h2>
          <p className="text-sm text-slate-500 mt-1.5 text-center">Create your profile to start applying for placement drives</p>
          <form onSubmit={submit} className="grid sm:grid-cols-2 gap-4 mt-7">
            <div><Field label="Full name" required error={errors.name}><input value={f.name} onChange={e => upd('name', e.target.value)} placeholder="Aarav Sharma" className={inputCls} /></Field></div>
            <div><Field label="Email" required error={errors.email}><input value={f.email} onChange={e => upd('email', e.target.value)} placeholder="you@student.edu" className={inputCls} /></Field></div>
            <div><Field label="Password" required error={errors.password}><input type="password" value={f.password} onChange={e => upd('password', e.target.value)} placeholder="Min 6 characters" className={inputCls} /></Field></div>
            <div><Field label="Confirm password" required error={errors.confirm}><input type="password" value={f.confirm} onChange={e => upd('confirm', e.target.value)} placeholder="Repeat password" className={inputCls} /></Field></div>
            <div><Field label="Phone" error={errors.phone}><input value={f.phone} onChange={e => upd('phone', e.target.value)} placeholder="+91 98765 43210" className={inputCls} /></Field></div>
            <div><Field label="CGPA (0–10)" error={errors.cgpa}><input value={f.cgpa} onChange={e => upd('cgpa', e.target.value)} placeholder="8.5" inputMode="decimal" className={inputCls} /></Field></div>
            <div><Field label="Department" required><select value={f.department} onChange={e => upd('department', e.target.value)} className={inputCls}>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}</select></Field></div>
            <div><Field label="Year" required><select value={f.year} onChange={e => upd('year', e.target.value)} className={inputCls}>{YEARS.map(y => <option key={y}>{y}</option>)}</select></Field></div>
            <div className="sm:col-span-2"><Field label="Skills (comma separated)"><input value={f.skills} onChange={e => upd('skills', e.target.value)} placeholder="Java, React, SQL" className={inputCls} /></Field></div>
            <div className="sm:col-span-2">
              <button disabled={busy} className="w-full py-3.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm hover:bg-[#16295c] transition disabled:opacity-60 flex items-center justify-center gap-2">
                {busy ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : <UserPlus className="w-4 h-4" />} {busy ? 'Creating account…' : 'Create student account'}
              </button>
              <p className="text-sm text-center text-slate-500 mt-4">Already registered? <Link to="/login" className="font-bold text-[#0b1f4b] hover:underline">Sign in</Link></p>
            </div>
          </form>
        </div>
        <p className="text-xs text-slate-400 text-center mt-4">Officers and admins are onboarded by the placement cell — contact placement@college.edu</p>
      </div>
    </div>
  );
}
