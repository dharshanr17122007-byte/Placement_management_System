import { useEffect, useState } from 'react';
import { Download, Users, Building2, FileCheck2, BadgeCheck, TrendingUp, Printer } from 'lucide-react';
import { api } from '../lib/api';
import { useToast } from '../components/Toast';
import StatCard from '../components/StatCard';
import { Spinner } from '../components/UI';
import { BarChart, DonutChart, HBar, ProgressRing } from '../components/Charts';
import { toCSV, downloadCSV } from '../lib/utils';

export default function Reports() {
  const { toast } = useToast();
  const [rep, setRep] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { api.get('/api/reports').then(setRep).catch(() => {}).finally(() => setLoading(false)); }, []);

  if (loading) return <Spinner label="Generating reports…" />;
  const t = rep?.totals || {};

  const exportDept = () => {
    downloadCSV('department-wise-report.csv', toCSV(rep.departmentWise || [], [
      { key: 'department', label: 'Department' }, { key: 'total', label: 'Total' }, { key: 'applied', label: 'Applied' }, { key: 'placed', label: 'Placed' }, { key: 'percentage', label: 'Placement %' },
    ]));
    toast('Department report downloaded', 'success');
  };
  const exportCompany = () => {
    downloadCSV('company-wise-report.csv', toCSV(rep.companyWise || [], [
      { key: 'company', label: 'Company' }, { key: 'applications', label: 'Applications' }, { key: 'shortlisted', label: 'Shortlisted' }, { key: 'selected', label: 'Selected' },
    ]));
    toast('Company report downloaded', 'success');
  };
  const exportSummary = () => {
    downloadCSV('placement-summary.csv', toCSV([{
      students: t.students, eligible: t.eligible, applied: t.appliedStudents, selected: t.selected,
      rejected: t.rejected, placed: t.placed, placement_pct: t.placementPct, companies: t.companies, jobs: t.jobs, openings: t.totalOpenings,
    }], [
      { key: 'students', label: 'Total Students' }, { key: 'eligible', label: 'Eligible' }, { key: 'applied', label: 'Applied' },
      { key: 'selected', label: 'Selected' }, { key: 'rejected', label: 'Rejected' }, { key: 'placed', label: 'Placed (unique)' },
      { key: 'placement_pct', label: 'Placement %' }, { key: 'companies', label: 'Companies' }, { key: 'jobs', label: 'Jobs' }, { key: 'openings', label: 'Openings' },
    ]));
    toast('Summary downloaded', 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">Reports & Analytics</h1><p className="text-sm text-slate-500">Placement performance at a glance · Academic Year 2025–26</p></div>
        <div className="flex gap-2">
          <button onClick={() => window.print()} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold hover:bg-slate-50"><Printer className="w-4 h-4" />Print</button>
          <button onClick={exportSummary} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c]"><Download className="w-4 h-4" />Summary CSV</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard label="Total Students" value={t.students ?? 0} icon={Users} tone="bg-sky-500" />
        <StatCard label="Eligible (CGPA≥6)" value={t.eligible ?? 0} icon={TrendingUp} tone="bg-indigo-500" />
        <StatCard label="Applied" value={t.appliedStudents ?? 0} icon={FileCheck2} tone="bg-amber-500" />
        <StatCard label="Selected" value={t.selected ?? 0} icon={BadgeCheck} tone="bg-emerald-500" />
        <StatCard label="Rejected" value={t.rejected ?? 0} icon={FileCheck2} tone="bg-rose-500" />
        <StatCard label="Placement %" value={`${t.placementPct ?? 0}%`} icon={Building2} tone="bg-violet-500" />
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="bg-white rounded-3xl border p-6 flex flex-col items-center">
          <p className="font-bold self-start">Placement Rate</p>
          <div className="py-5"><ProgressRing pct={t.placementPct ?? 0} size={150} /></div>
          <p className="text-xs text-slate-500 text-center">{t.placed} placed · {t.appliedStudents} participated · {t.companies} recruiters</p>
        </div>
        <div className="bg-white rounded-3xl border p-6 lg:col-span-2">
          <p className="font-bold mb-4">Funnel: Applied → Shortlisted → Selected → Rejected</p>
          <DonutChart data={[
            { name: 'Applied', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Applied')?.value || 0, color: '#0ea5e9' },
            { name: 'Shortlisted', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Shortlisted')?.value || 0, color: '#f59e0b' },
            { name: 'Selected', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Selected')?.value || 0, color: '#10b981' },
            { name: 'Rejected', value: rep?.statusBreakdown?.find((x: any) => x.name === 'Rejected')?.value || 0, color: '#f43f5e' },
          ]} />
        </div>
      </div>

      <div className="bg-white rounded-3xl border p-6">
        <p className="font-bold mb-4">Monthly Applications vs Selections</p>
        <BarChart data={(rep?.monthly || []).map((m: any) => ({ label: m.month, value: m.applications, value2: m.selected }))} height={240} />
        <div className="flex gap-4 mt-3 text-xs text-slate-500"><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-[#0b1f4b]" />Applications</span><span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-500" />Selected</span></div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="bg-white rounded-3xl border p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold">Department-wise Report</p><button onClick={exportDept} className="text-xs font-bold text-sky-600 hover:underline flex items-center gap-1"><Download className="w-3.5 h-3.5" />CSV</button></div>
          <div className="overflow-x-auto"><table className="w-full text-sm min-w-[380px]">
            <thead><tr className="text-left text-[11px] uppercase text-slate-400 border-b"><th className="py-2">Dept</th><th className="py-2">Total</th><th className="py-2">Applied</th><th className="py-2">Placed</th><th className="py-2">%</th></tr></thead>
            <tbody>{(rep?.departmentWise || []).map((d: any) => <tr key={d.department} className="border-b last:border-0"><td className="py-2.5 font-bold">{d.department}</td><td className="py-2.5">{d.total}</td><td className="py-2.5">{d.applied}</td><td className="py-2.5 font-bold text-emerald-700">{d.placed}</td><td className="py-2.5"><span className="text-xs font-extrabold bg-sky-50 text-sky-700 px-2 py-0.5 rounded-full">{d.percentage}%</span></td></tr>)}</tbody>
          </table></div>
        </div>
        <div className="bg-white rounded-3xl border p-6">
          <div className="flex items-center justify-between mb-4"><p className="font-bold">Company-wise Report</p><button onClick={exportCompany} className="text-xs font-bold text-sky-600 hover:underline flex items-center gap-1"><Download className="w-3.5 h-3.5" />CSV</button></div>
          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
            {(rep?.companyWise || []).map((c: any, i: number) => (
              <div key={i}><HBar label={`${c.company} (${c.applications} appl.)`} value={c.selected} max={Math.max(1, ...(rep?.companyWise || []).map((x: any) => x.selected))} color="#10b981" /><p className="text-[11px] text-slate-400 mt-0.5">{c.shortlisted} shortlisted</p></div>
            ))}
            {(!rep?.companyWise || rep.companyWise.length === 0) && <p className="text-sm text-slate-400 text-center py-6">No data yet</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
