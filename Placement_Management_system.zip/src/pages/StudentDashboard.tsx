import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, FileCheck2, CalendarClock, BadgeCheck, ArrowRight, MapPin, IndianRupee, Upload, AlertCircle } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import StatCard from '../components/StatCard';
import { Spinner, Badge } from '../components/UI';
import { formatDateTime, formatDate } from '../lib/utils';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [student, setStudent] = useState<any>(null);
  const [apps, setApps] = useState<any[]>([]);
  const [interviews, setInterviews] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const s = await api.get(`/api/students?user_id=${user.id}&limit=1`);
        const me = (s.data || [])[0] || null;
        setStudent(me);
        const [a, j] = await Promise.all([api.get('/api/applications?limit=200'), api.get('/api/jobs?status=open&limit=50')]);
        const mine = (a.data || []).filter((x: any) => me && x.student_id === me.id);
        setApps(mine);
        if (me) {
          const iv = await api.get(`/api/interviews?student_id=${me.id}`);
          setInterviews((iv || []).filter((x: any) => new Date(x.scheduled_at) >= new Date()).slice(0, 4));
        }
        const appliedIds = new Set(mine.map((x: any) => x.job_id));
        setJobs((j.data || []).filter((x: any) => !appliedIds.has(x.id)).slice(0, 4));
      } catch {} finally { setLoading(false); }
    })();
  }, [user?.id]);

  if (loading) return <Spinner label="Loading your dashboard…" />;

  const selected = apps.filter(a => a.status === 'selected').length;
  const profilePct = [student?.phone, student?.cgpa, student?.skills, student?.resume_url].filter(Boolean).length;
  const profileDone = Math.round(((profilePct + 2) / 6) * 100);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-[#0b1f4b] via-[#12306e] to-sky-700 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden">
        <div className="relative z-10">
          <p className="text-amber-300 text-xs font-bold uppercase tracking-widest">Student Dashboard · {student?.student_id || ''}</p>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">Hey {user?.name?.split(' ')[0]}! Ready to get placed? 🚀</h1>
          <p className="text-white/70 text-sm mt-1.5">{student?.department} · {student?.year} Year · CGPA {student?.cgpa ?? '—'}</p>
          <div className="flex flex-wrap gap-2.5 mt-5">
            <Link to="/jobs" className="px-5 py-2.5 rounded-xl bg-amber-400 text-[#0b1f4b] text-sm font-bold hover:bg-amber-300">Browse Jobs</Link>
            <Link to="/profile" className="px-5 py-2.5 rounded-xl border border-white/30 text-sm font-bold hover:bg-white/10">Complete Profile</Link>
          </div>
        </div>
      </div>

      {!student?.resume_url && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
          <div className="flex-1"><p className="text-sm font-bold text-amber-900">Upload your resume to unlock applications</p><p className="text-xs text-amber-700 mt-0.5">Recruiters shortlist profiles with resumes 3× more often.</p></div>
          <Link to="/profile" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 text-white text-xs font-bold hover:bg-amber-600 shrink-0"><Upload className="w-3.5 h-3.5" />Upload</Link>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Applications" value={apps.length} icon={FileCheck2} tone="bg-sky-500" sub="jobs applied" />
        <StatCard label="Shortlisted" value={apps.filter(a => ['shortlisted', 'selected'].includes(a.status)).length} icon={Briefcase} tone="bg-amber-500" sub="moving forward" />
        <StatCard label="Interviews" value={interviews.length} icon={CalendarClock} tone="bg-violet-500" sub="upcoming rounds" />
        <StatCard label="Offers" value={selected} icon={BadgeCheck} tone="bg-emerald-500" sub={selected ? 'Congratulations!' : 'keep applying'} />
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        <div className="bg-white rounded-3xl border border-slate-200 p-6 lg:col-span-3">
          <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">Recommended for you</p><Link to="/jobs" className="text-xs font-bold text-sky-600 hover:underline flex items-center gap-1">All jobs <ArrowRight className="w-3.5 h-3.5" /></Link></div>
          <div className="grid sm:grid-cols-2 gap-3">
            {jobs.map(j => (
              <Link key={j.id} to={`/jobs?search=${encodeURIComponent(j.title)}`} className="p-4 rounded-2xl border border-slate-100 hover:border-amber-300 hover:shadow-md transition group">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl bg-[#0b1f4b] text-amber-400 font-extrabold flex items-center justify-center text-xs shrink-0">{(j.company?.name || 'C').slice(0, 2).toUpperCase()}</div>
                  <div className="min-w-0"><p className="font-bold text-sm group-hover:text-[#0b1f4b] truncate">{j.title}</p><p className="text-xs text-slate-500 truncate">{j.company?.name}</p></div>
                </div>
                <div className="flex items-center gap-3 mt-3 text-[11px] text-slate-500 font-medium">
                  <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{j.location || 'On-campus'}</span>
                  {j.package_lpa && <span className="flex items-center gap-0.5 font-bold text-emerald-700"><IndianRupee className="w-3 h-3" />{j.package_lpa} LPA</span>}
                </div>
                <div className="flex items-center gap-2 mt-2.5 text-[11px]"><span className="px-2 py-0.5 rounded-full bg-slate-100 font-bold text-slate-600">{j.department}</span><span className="px-2 py-0.5 rounded-full bg-slate-100 font-bold text-slate-600">CGPA ≥ {j.min_cgpa}</span></div>
              </Link>
            ))}
            {jobs.length === 0 && <p className="text-sm text-slate-400 text-center py-6 sm:col-span-2">You've applied to all open jobs. New drives coming soon!</p>}
          </div>
        </div>
        <div className="space-y-5 lg:col-span-2">
          <div className="bg-white rounded-3xl border border-slate-200 p-6">
            <p className="font-bold text-slate-800 mb-3">Profile Strength</p>
            <div className="flex items-center gap-4">
              <div className="relative w-20 h-20 shrink-0">
                <svg viewBox="0 0 80 80" className="w-20 h-20 -rotate-90"><circle cx="40" cy="40" r="34" fill="none" stroke="#f1f5f9" strokeWidth="9" /><circle cx="40" cy="40" r="34" fill="none" stroke="#f59e0b" strokeWidth="9" strokeLinecap="round" strokeDasharray={`${(profileDone / 100) * 213.6} 213.6`} /></svg>
                <span className="absolute inset-0 flex items-center justify-center font-extrabold text-sm">{profileDone}%</span>
              </div>
              <div className="text-xs space-y-1.5 text-slate-600">
                <p>{student?.phone ? '✅' : '⬜'} Phone number</p>
                <p>{student?.skills ? '✅' : '⬜'} Skills listed</p>
                <p>{student?.resume_url ? '✅' : '⬜'} Resume uploaded</p>
              </div>
            </div>
            <Link to="/profile" className="block text-center mt-4 text-xs font-bold text-sky-600 hover:underline">Improve profile →</Link>
          </div>
          <div className="bg-white rounded-3xl border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-3"><p className="font-bold text-slate-800">Upcoming Interviews</p><Link to="/interviews" className="text-xs font-bold text-sky-600 hover:underline">All →</Link></div>
            <div className="space-y-2.5">
              {interviews.map(iv => (
                <div key={iv.id} className="p-3 rounded-2xl bg-violet-50 border border-violet-100"><p className="text-sm font-bold">{iv.round_name}</p><p className="text-xs text-slate-600 mt-0.5">{iv.job?.title} @ {iv.company?.name}</p><p className="text-[11px] font-bold text-violet-700 mt-1">{formatDateTime(iv.scheduled_at)} · {iv.venue || iv.mode}</p></div>
              ))}
              {interviews.length === 0 && <p className="text-xs text-slate-400 text-center py-3">No interviews scheduled yet</p>}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4"><p className="font-bold text-slate-800">My Recent Applications</p><Link to="/applications" className="text-xs font-bold text-sky-600 hover:underline">Track all →</Link></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[560px]">
            <thead><tr className="text-left text-[11px] uppercase tracking-wider text-slate-400 border-b"><th className="py-2.5 pr-4">Job</th><th className="py-2.5 pr-4">Company</th><th className="py-2.5 pr-4">Applied</th><th className="py-2.5">Status</th></tr></thead>
            <tbody>
              {apps.slice(0, 5).map(a => (
                <tr key={a.id} className="border-b last:border-0"><td className="py-3 pr-4 font-semibold">{a.job?.title}</td><td className="py-3 pr-4 text-slate-600">{a.company?.name}</td><td className="py-3 pr-4 text-slate-500 text-xs">{formatDate(a.applied_at)}</td><td className="py-3"><Badge value={a.status} /></td></tr>
              ))}
              {apps.length === 0 && <tr><td colSpan={4} className="py-6 text-center text-slate-400 text-sm">No applications yet — <Link to="/jobs" className="font-bold text-sky-600">browse jobs</Link></td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
