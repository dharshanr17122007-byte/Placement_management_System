import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Search, Pencil, Trash2, Download, Eye, X } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Modal, ConfirmDialog, Field, inputCls, Empty, Spinner, Pagination, Badge } from '../components/UI';
import { isEmail, isPhone, isCGPA, DEPARTMENTS, YEARS, toCSV, downloadCSV, formatDate, initials } from '../lib/utils';

const empty = { name: '', email: '', phone: '', department: 'CSE', year: '3rd', cgpa: '', skills: '', status: 'active' };

export default function Students() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sp, setSp] = useSearchParams();
  const [rows, setRows] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState(sp.get('search') || '');
  const [dept, setDept] = useState('');
  const [year, setYear] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...empty });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [del, setDel] = useState<any>(null);
  const [view, setView] = useState<any>(null);
  const canEdit = user?.role === 'admin' || user?.role === 'officer';
  const LIMIT = 12;

  const fetchRows = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (search) q.set('search', search);
      if (dept) q.set('department', dept);
      if (year) q.set('year', year);
      if (status) q.set('status', status);
      const d = await api.get(`/api/students?${q.toString()}`);
      setRows(d.data || []); setTotal(d.total || 0);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchRows(); }, [page, dept, year, status]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); fetchRows(); }, 450); return () => clearTimeout(t); }, [search]);
  useEffect(() => { const s = sp.get('search'); if (s) setSearch(s); }, []);

  const openAdd = () => { setEditing(null); setForm({ ...empty }); setErrors({}); setModal(true); };
  const openEdit = (r: any) => { setEditing(r); setForm({ ...r, cgpa: r.cgpa ?? '' }); setErrors({}); setModal(true); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = 'Name required';
    if (!isEmail(form.email)) e.email = 'Valid email required';
    if (form.phone && !isPhone(form.phone)) e.phone = 'Invalid phone';
    if (!isCGPA(form.cgpa)) e.cgpa = 'CGPA 0–10';
    if (!form.department) e.department = 'Required';
    if (!form.year) e.year = 'Required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = async () => {
    if (!validate()) return;
    try {
      if (editing) await api.put('/api/students', { ...form, id: editing.id, cgpa: form.cgpa === '' ? null : Number(form.cgpa) });
      else await api.post('/api/students', { ...form, cgpa: form.cgpa === '' ? null : Number(form.cgpa) });
      toast(editing ? 'Student updated' : 'Student added', 'success');
      setModal(false); fetchRows();
    } catch (e: any) { toast(e.message, 'error'); }
  };

  const remove = async () => {
    try { await api.del(`/api/students?id=${del.id}`); toast('Student deleted', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  const exportCSV = () => {
    const csv = toCSV(rows, [
      { key: 'student_id', label: 'Student ID' }, { key: 'name', label: 'Name' }, { key: 'email', label: 'Email' },
      { key: 'phone', label: 'Phone' }, { key: 'department', label: 'Department' }, { key: 'year', label: 'Year' },
      { key: 'cgpa', label: 'CGPA' }, { key: 'skills', label: 'Skills' }, { key: 'status', label: 'Status' },
    ]);
    downloadCSV('students.csv', csv);
    toast('Students exported to CSV', 'success');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">Student Management</h1><p className="text-sm text-slate-500">{total} students on record</p></div>
        <div className="flex gap-2">
          <button onClick={exportCSV} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold hover:bg-slate-50"><Download className="w-4 h-4" />Export</button>
          {canEdit && <button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c]"><Plus className="w-4 h-4" />Add Student</button>}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, ID, email, skills…" className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-[#0b1f4b]" />{search && <button onClick={() => setSearch('')} className="absolute right-3 top-3 text-slate-400"><X className="w-4 h-4" /></button>}</div>
        <select value={dept} onChange={e => { setDept(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Departments</option>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}</select>
        <select value={year} onChange={e => { setYear(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Years</option>{YEARS.map(y => <option key={y}>{y}</option>)}</select>
        <select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Status</option><option value="active">Active</option><option value="placed">Placed</option><option value="inactive">Inactive</option></select>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading students…" /></div> : rows.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title="No students found" sub="Try adjusting search or filters" /></div> : (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[820px]">
              <thead><tr className="text-left text-[11px] uppercase tracking-wider text-slate-400 border-b bg-slate-50/60"><th className="py-3 px-4">Student</th><th className="py-3 px-4">ID</th><th className="py-3 px-4">Dept / Year</th><th className="py-3 px-4">CGPA</th><th className="py-3 px-4">Status</th><th className="py-3 px-4 text-right">Actions</th></tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id} className="border-b last:border-0 hover:bg-slate-50/60">
                    <td className="py-3 px-4"><div className="flex items-center gap-3"><span className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0b1f4b] to-sky-600 text-white text-xs font-bold flex items-center justify-center shrink-0">{initials(r.name)}</span><div><p className="font-bold">{r.name}</p><p className="text-xs text-slate-500">{r.email}</p></div></div></td>
                    <td className="py-3 px-4 font-mono text-xs">{r.student_id}</td>
                    <td className="py-3 px-4"><span className="font-semibold">{r.department}</span><span className="text-slate-400"> · {r.year}</span></td>
                    <td className="py-3 px-4 font-bold">{r.cgpa ?? '—'}</td>
                    <td className="py-3 px-4"><Badge value={r.status} /></td>
                    <td className="py-3 px-4"><div className="flex justify-end gap-1.5">
                      <button onClick={() => setView(r)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" title="View"><Eye className="w-4 h-4" /></button>
                      {canEdit && <><button onClick={() => openEdit(r)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-600" title="Edit"><Pencil className="w-4 h-4" /></button><button onClick={() => setDel(r)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600" title="Delete"><Trash2 className="w-4 h-4" /></button></>}
                    </div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <Pagination page={page} total={total} limit={LIMIT} onPage={setPage} />

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Student' : 'Add Student'} wide>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Full name" required error={errors.name}><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className={inputCls} placeholder="Priya Nair" /></Field>
          <Field label="Email" required error={errors.email}><input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className={inputCls} placeholder="priya@student.edu" /></Field>
          <Field label="Phone" error={errors.phone}><input value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} className={inputCls} placeholder="+91 98765 43210" /></Field>
          <Field label="CGPA (0–10)" error={errors.cgpa}><input value={form.cgpa} onChange={e => setForm({ ...form, cgpa: e.target.value })} className={inputCls} placeholder="8.5" inputMode="decimal" /></Field>
          <Field label="Department" required><select value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className={inputCls}>{DEPARTMENTS.map(d => <option key={d}>{d}</option>)}</select></Field>
          <Field label="Year" required><select value={form.year} onChange={e => setForm({ ...form, year: e.target.value })} className={inputCls}>{YEARS.map(y => <option key={y}>{y}</option>)}</select></Field>
          <div className="sm:col-span-2"><Field label="Skills (comma separated)"><input value={form.skills || ''} onChange={e => setForm({ ...form, skills: e.target.value })} className={inputCls} placeholder="Python, SQL, React" /></Field></div>
          <Field label="Status"><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className={inputCls}><option value="active">Active</option><option value="placed">Placed</option><option value="inactive">Inactive</option></select></Field>
          <div className="sm:col-span-2 flex gap-3 pt-2">
            <button onClick={() => setModal(false)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm hover:bg-slate-50">Cancel</button>
            <button onClick={save} className="flex-1 py-2.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm hover:bg-[#16295c]">{editing ? 'Save changes' : 'Add student'}</button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Delete student?" message={`Remove ${del?.name} and all their applications & interviews? This cannot be undone.`} />

      <Modal open={!!view} onClose={() => setView(null)} title="Student Profile">
        {view && (
          <div className="space-y-4">
            <div className="flex items-center gap-4"><span className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#0b1f4b] to-sky-600 text-white font-bold flex items-center justify-center text-lg">{initials(view.name)}</span><div><p className="font-extrabold text-lg">{view.name}</p><p className="text-sm text-slate-500 font-mono">{view.student_id}</p></div><span className="ml-auto"><Badge value={view.status} /></span></div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[['Email', view.email], ['Phone', view.phone || '—'], ['Department', view.department], ['Year', view.year], ['CGPA', view.cgpa ?? '—'], ['Registered', formatDate(view.created_at)]].map(([k, v]) => (
                <div key={k} className="bg-slate-50 rounded-xl p-3"><p className="text-[11px] font-bold uppercase text-slate-400">{k}</p><p className="font-semibold mt-0.5 break-all">{v}</p></div>
              ))}
            </div>
            <div className="bg-slate-50 rounded-xl p-3"><p className="text-[11px] font-bold uppercase text-slate-400">Skills</p><div className="flex flex-wrap gap-1.5 mt-2">{String(view.skills || '').split(',').map(s => s.trim()).filter(Boolean).map((s, i) => <span key={i} className="text-xs font-bold bg-white border px-2.5 py-1 rounded-full">{s}</span>)}{!view.skills && <p className="text-sm text-slate-400">No skills listed</p>}</div></div>
            {view.resume_url && <a href={view.resume_url} target="_blank" rel="noreferrer" className="block text-center py-2.5 rounded-xl bg-emerald-600 text-white text-sm font-bold hover:bg-emerald-700">View Resume</a>}
          </div>
        )}
      </Modal>
    </div>
  );
  void setSp;
}
