import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, ShieldCheck, Briefcase, GraduationCap, Search } from 'lucide-react';
import { api } from '../lib/api';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { Modal, ConfirmDialog, Field, inputCls, Spinner, Empty } from '../components/UI';
import { isEmail, initials, formatDate } from '../lib/utils';

const empty = { name: '', email: '', password: '', role: 'officer', phone: '' };

export default function Users() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleF, setRoleF] = useState('');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<any>({ ...empty });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [del, setDel] = useState<any>(null);

  const fetchRows = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams();
      if (roleF) q.set('role', roleF);
      if (search) q.set('search', search);
      const d = await api.get(`/api/users?${q.toString()}`);
      setRows(d || []);
    } catch (e: any) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchRows(); }, [roleF]);
  useEffect(() => { const t = setTimeout(fetchRows, 450); return () => clearTimeout(t); }, [search]);

  const openAdd = () => { setEditing(null); setForm({ ...empty }); setErrors({}); setModal(true); };
  const openEdit = (r: any) => { setEditing(r); setForm({ name: r.name, email: r.email, password: '', role: r.role, phone: r.phone || '' }); setErrors({}); setModal(true); };

  const save = async () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = 'Name required';
    if (!editing && !isEmail(form.email)) e.email = 'Valid email required';
    if (!editing && form.password.length < 6) e.password = 'Min 6 chars';
    if (editing && form.password && form.password.length < 6) e.password = 'Min 6 chars';
    setErrors(e);
    if (Object.keys(e).length) return;
    try {
      if (editing) await api.put('/api/users', { id: editing.id, name: form.name, phone: form.phone, role: form.role, ...(form.password ? { password: form.password } : {}) });
      else await api.post('/api/users', form);
      toast(editing ? 'User updated' : 'User created', 'success');
      setModal(false); fetchRows();
    } catch (err: any) { toast(err.message, 'error'); }
  };
  const remove = async () => {
    if (del.id === user?.id) { toast('You cannot delete your own account', 'error'); return; }
    try { await api.del(`/api/users?id=${del.id}`); toast('User deleted', 'success'); fetchRows(); }
    catch (e: any) { toast(e.message, 'error'); }
  };

  const roleIcon = (r: string) => r === 'admin' ? <ShieldCheck className="w-3.5 h-3.5" /> : r === 'officer' ? <Briefcase className="w-3.5 h-3.5" /> : <GraduationCap className="w-3.5 h-3.5" />;
  const roleCls = (r: string) => r === 'admin' ? 'bg-violet-100 text-violet-700' : r === 'officer' ? 'bg-amber-100 text-amber-800' : 'bg-sky-100 text-sky-700';

  const counts = { admin: rows.filter(r => r.role === 'admin').length, officer: rows.filter(r => r.role === 'officer').length, student: rows.filter(r => r.role === 'student').length };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div><h1 className="text-2xl font-extrabold text-slate-900">Users & Officers</h1><p className="text-sm text-slate-500">{rows.length} accounts · {counts.admin} admins · {counts.officer} officers · {counts.student} students</p></div>
        <button onClick={openAdd} className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0b1f4b] text-white text-sm font-bold hover:bg-[#16295c] w-fit"><Plus className="w-4 h-4" />Add User</button>
      </div>

      <div className="bg-white rounded-2xl border p-4 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users…" className="w-full pl-10 py-2.5 rounded-xl border border-slate-200 text-sm outline-none focus:border-[#0b1f4b]" /></div>
        <select value={roleF} onChange={e => setRoleF(e.target.value)} className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm"><option value="">All Roles</option><option value="admin">Admin</option><option value="officer">Officer</option><option value="student">Student</option></select>
      </div>

      {loading ? <div className="bg-white rounded-2xl border"><Spinner label="Loading users…" /></div> : rows.length === 0 ? <div className="bg-white rounded-2xl border"><Empty title="No users found" /></div> : (
        <div className="bg-white rounded-2xl border overflow-hidden">
          <div className="overflow-x-auto"><table className="w-full text-sm min-w-[680px]">
            <thead><tr className="text-left text-[11px] uppercase tracking-wider text-slate-400 border-b bg-slate-50/60"><th className="py-3 px-4">User</th><th className="py-3 px-4">Role</th><th className="py-3 px-4">Phone</th><th className="py-3 px-4">Joined</th><th className="py-3 px-4 text-right">Actions</th></tr></thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id} className="border-b last:border-0 hover:bg-slate-50/60">
                  <td className="py-3 px-4"><div className="flex items-center gap-3"><span className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0b1f4b] to-sky-600 text-white text-xs font-bold flex items-center justify-center">{initials(r.name)}</span><div><p className="font-bold">{r.name}{r.id === user?.id && <span className="ml-2 text-[10px] font-extrabold bg-slate-100 px-2 py-0.5 rounded-full">YOU</span>}</p><p className="text-xs text-slate-500">{r.email}</p></div></div></td>
                  <td className="py-3 px-4"><span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold capitalize ${roleCls(r.role)}`}>{roleIcon(r.role)}{r.role}</span></td>
                  <td className="py-3 px-4 text-slate-600">{r.phone || '—'}</td>
                  <td className="py-3 px-4 text-slate-500 text-xs">{formatDate(r.created_at)}</td>
                  <td className="py-3 px-4"><div className="flex justify-end gap-1.5">
                    <button onClick={() => openEdit(r)} className="p-2 rounded-lg hover:bg-sky-50 text-sky-600"><Pencil className="w-4 h-4" /></button>
                    {r.id !== user?.id && <button onClick={() => setDel(r)} className="p-2 rounded-lg hover:bg-rose-50 text-rose-600"><Trash2 className="w-4 h-4" /></button>}
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table></div>
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit User' : 'Add User / Officer'}>
        <div className="space-y-4">
          <Field label="Full name" required error={errors.name}><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className={inputCls} placeholder="Ananya Iyer" /></Field>
          {!editing && <Field label="Email" required error={errors.email}><input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className={inputCls} placeholder="officer2@college.edu" /></Field>}
          <div className="grid grid-cols-2 gap-4">
            <Field label="Role"><select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className={inputCls}><option value="officer">Placement Officer</option><option value="admin">Admin</option><option value="student">Student</option></select></Field>
            <Field label="Phone"><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className={inputCls} placeholder="+91…" /></Field>
          </div>
          <Field label={editing ? 'New password (leave blank to keep)' : 'Password'} required={!editing} error={errors.password}><input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} className={inputCls} placeholder="Min 6 characters" /></Field>
          <div className="flex gap-3"><button onClick={() => setModal(false)} className="flex-1 py-2.5 rounded-xl border font-bold text-sm">Cancel</button><button onClick={save} className="flex-1 py-2.5 rounded-xl bg-[#0b1f4b] text-white font-bold text-sm">{editing ? 'Save' : 'Create user'}</button></div>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} onClose={() => setDel(null)} onConfirm={remove} title="Delete user?" message={`Remove ${del?.name} (${del?.email})? Their login will stop working.`} />
    </div>
  );
}
